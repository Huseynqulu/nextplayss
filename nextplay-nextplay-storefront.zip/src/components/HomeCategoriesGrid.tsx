import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import {
  ArrowRight,
  BadgePercent,
  Gamepad2,
  Gift,
  KeyRound,
  LayoutGrid,
  Monitor,
  Wallet,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

const pcPlatforms = "PC,Steam,EA,Epic Games,Epic,Rockstar,Battle.net";
const psPlatforms = "PlayStation,PS5,PS4";

type HomeCategory = {
  id: string;
  title: string;
  subtitle: string | null;
  image_url: string | null;
  link_url: string;
  sort_order: number;
};

const coreCategories = [
  {
    id: "playstation",
    title: "PlayStation",
    subtitle: "PS4 və PS5 oyunları",
    icon: Gamepad2,
    to: "/marketplace",
    search: { platforms: psPlatforms },
    className: "from-[#006fcd]/30 via-[#006fcd]/10 to-transparent",
  },
  {
    id: "pc",
    title: "PC Oyunları",
    subtitle: "Steam, EA, Epic və daha çox",
    icon: Monitor,
    to: "/marketplace",
    search: { platforms: pcPlatforms, cat: "Games" },
    className: "from-neon/25 via-primary/10 to-transparent",
  },
  {
    id: "steam",
    title: "Steam",
    subtitle: "Oyunlar və açarlar",
    icon: KeyRound,
    to: "/marketplace",
    search: { platform: "Steam" },
    className: "from-sky-500/25 via-sky-500/5 to-transparent",
  },
  {
    id: "gift",
    title: "Hədiyyə kartları",
    subtitle: "Rəqəmsal kart və kodlar",
    icon: Gift,
    to: "/gift-cards",
    search: undefined,
    className: "from-violet-500/25 via-violet-500/5 to-transparent",
  },
  {
    id: "wallet",
    title: "Balans artır",
    subtitle: "NextPlay cüzdanını doldur",
    icon: Wallet,
    to: "/wallet",
    search: undefined,
    className: "from-emerald-500/20 via-emerald-500/5 to-transparent",
  },
  {
    id: "deals",
    title: "Sərfəli təkliflər",
    subtitle: "Endirimli məhsulları kəşf et",
    icon: BadgePercent,
    to: "/marketplace",
    search: { sort: "low" },
    className: "from-amber-500/20 via-orange-500/5 to-transparent",
  },
] as const;

export function HomeCategoriesGrid() {
  const [customCategories, setCustomCategories] = useState<HomeCategory[]>([]);

  useEffect(() => {
    supabase
      .from("home_categories" as any)
      .select("id,title,subtitle,image_url,link_url,sort_order")
      .eq("active", true)
      .order("sort_order", { ascending: true })
      .limit(8)
      .then(({ data }) => setCustomCategories(((data as any) ?? []) as HomeCategory[]));
  }, []);

  const uniqueCustom = useMemo(() => customCategories.slice(0, 4), [customCategories]);

  return (
    <section className="mx-auto max-w-[1440px] px-4 py-9 sm:px-6 lg:px-8 lg:py-12">
      <div className="mb-5 flex items-end justify-between gap-4">
        <div>
          <div className="mb-2 inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em] text-neon">
            <LayoutGrid className="h-4 w-4" /> Kataloq
          </div>
          <h2 className="font-display text-2xl font-black sm:text-3xl">Kateqoriyaya görə kəşf et</h2>
          <p className="mt-1 text-sm text-muted-foreground">PlayStation, PC və rəqəmsal məhsullar bir yerdə.</p>
        </div>
        <Link to="/marketplace" className="hidden items-center gap-1.5 text-sm font-black text-neon hover:underline sm:inline-flex">
          Bütün məhsullar <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        {coreCategories.map((category) => {
          const Icon = category.icon;
          return (
            <Link
              key={category.id}
              to={category.to as any}
              search={category.search as any}
              className="group relative min-h-[154px] overflow-hidden rounded-2xl border border-border bg-card p-4 transition hover:-translate-y-1 hover:border-neon/45 hover:shadow-[0_18px_50px_-26px_hsl(var(--neon)/0.55)] sm:p-5"
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${category.className}`} />
              <div className="relative flex h-full flex-col">
                <div className="mb-auto grid h-11 w-11 place-items-center rounded-xl border border-white/8 bg-background/55 text-neon backdrop-blur-sm transition group-hover:scale-105">
                  <Icon className="h-5 w-5" />
                </div>
                <div className="mt-6">
                  <p className="text-sm font-black sm:text-base">{category.title}</p>
                  <p className="mt-1 text-[11px] leading-4 text-muted-foreground sm:text-xs">{category.subtitle}</p>
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      {uniqueCustom.length > 0 && (
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {uniqueCustom.map((category) => (
            <Link
              key={category.id}
              to={category.link_url as any}
              className="group relative h-28 overflow-hidden rounded-2xl border border-border bg-card transition hover:border-neon/40"
            >
              {category.image_url ? (
                <img src={category.image_url} alt={category.title} loading="lazy" className="absolute inset-0 h-full w-full object-cover opacity-65 transition duration-500 group-hover:scale-105 group-hover:opacity-80" />
              ) : (
                <div className="absolute inset-0 bg-gradient-to-br from-primary/25 to-neon/5" />
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/35 to-transparent" />
              <div className="absolute inset-x-0 bottom-0 p-3.5 text-white">
                <p className="text-sm font-black">{category.title}</p>
                {category.subtitle && <p className="mt-0.5 line-clamp-1 text-[10px] text-white/70">{category.subtitle}</p>}
              </div>
            </Link>
          ))}
        </div>
      )}
    </section>
  );
}

export default HomeCategoriesGrid;
