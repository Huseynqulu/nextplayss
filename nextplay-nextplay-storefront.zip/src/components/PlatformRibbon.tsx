import { Link } from "@tanstack/react-router";
import { BadgePercent, Gift, Gamepad2, Headphones, KeyRound, Monitor, Wallet } from "lucide-react";

const pcPlatforms = "PC,Steam,EA,Epic Games,Epic,Rockstar,Battle.net";
const psPlatforms = "PlayStation,PS5,PS4";

const items = [
  { label: "PlayStation", icon: Gamepad2, to: "/marketplace", search: { platforms: psPlatforms } },
  { label: "PC Oyunları", icon: Monitor, to: "/marketplace", search: { platforms: pcPlatforms, cat: "Games" } },
  { label: "Steam", icon: KeyRound, to: "/marketplace", search: { platform: "Steam" } },
  { label: "Hədiyyə kartları", icon: Gift, to: "/gift-cards", search: undefined },
  { label: "Balans artır", icon: Wallet, to: "/wallet", search: undefined },
  { label: "Sərfəli təkliflər", icon: BadgePercent, to: "/marketplace", search: { sort: "low" } },
  { label: "Dəstək", icon: Headphones, to: "/support", search: undefined },
] as const;

export function PlatformRibbon() {
  return (
    <div className="border-b border-border/60 bg-surface/35">
      <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-1 overflow-x-auto py-2 no-scrollbar">
          {items.map(({ label, icon: Icon, to, search }) => (
            <Link
              key={label}
              to={to as any}
              search={search as any}
              className="flex h-9 shrink-0 items-center gap-2 rounded-lg px-3 text-xs font-bold text-muted-foreground transition hover:bg-background hover:text-foreground"
            >
              <Icon className="h-3.5 w-3.5 text-neon" />
              {label}
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
