import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Clock3, ShieldCheck, Sparkles, Zap } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Lang } from "@/lib/i18n";

export function AnnouncementBar() {
  const lang = ((typeof document !== "undefined" && document.documentElement.lang) || "az") as Lang;
  const [timeLeft, setTimeLeft] = useState<{ d: number; h: number; m: number; s: number } | null>(null);

  const { data: campaign } = useQuery({
    queryKey: ["announcement-campaign", lang],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("active_hero_campaigns" as any)
        .select("*")
        .eq("hero_placement", "announcement")
        .order("hero_priority", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error || !data) return null;
      return data as any;
    },
  });

  useEffect(() => {
    if (!campaign?.ends_at || !campaign?.hero_countdown_enabled) {
      setTimeLeft(null);
      return;
    }

    const target = new Date(campaign.ends_at).getTime();
    const update = () => {
      const diff = target - Date.now();
      if (diff <= 0) {
        setTimeLeft(null);
        return;
      }
      setTimeLeft({
        d: Math.floor(diff / 86400000),
        h: Math.floor((diff % 86400000) / 3600000),
        m: Math.floor((diff % 3600000) / 60000),
        s: Math.floor((diff % 60000) / 1000),
      });
    };

    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [campaign?.ends_at, campaign?.hero_countdown_enabled]);

  const headline = campaign?.[`hero_headline_${lang}`] || campaign?.hero_headline_az;
  const cta = campaign?.[`hero_cta_${lang}`] || campaign?.hero_cta_az || "Təkliflərə bax";
  const destination = campaign?.hero_cta_dest || "/marketplace";

  return (
    <div className="border-b border-neon/15 bg-gradient-to-r from-primary/12 via-neon/8 to-primary/12">
      <div className="mx-auto flex min-h-10 max-w-[1440px] items-center gap-5 overflow-x-auto px-4 py-2 text-[11px] no-scrollbar sm:px-6 lg:px-8">
        {campaign ? (
          <>
            <div className="flex shrink-0 items-center gap-2 font-bold">
              <Sparkles className="h-3.5 w-3.5 text-neon" />
              <span>{headline}</span>
              {campaign.code && <span className="rounded-md border border-dashed border-neon/40 bg-neon/8 px-2 py-0.5 font-mono text-neon">{campaign.code}</span>}
            </div>
            {timeLeft && (
              <div className="flex shrink-0 items-center gap-1.5 text-muted-foreground">
                <Clock3 className="h-3.5 w-3.5" />
                <span>{timeLeft.d}g {timeLeft.h}s {timeLeft.m}d {timeLeft.s}s</span>
              </div>
            )}
            <Link to={destination as any} className="shrink-0 font-black text-neon hover:underline">{cta} →</Link>
          </>
        ) : (
          <>
            <span className="flex shrink-0 items-center gap-1.5 font-bold"><Zap className="h-3.5 w-3.5 text-neon" /> Sürətli rəqəmsal çatdırılma</span>
            <span className="h-4 w-px shrink-0 bg-border" />
            <span className="flex shrink-0 items-center gap-1.5 font-bold"><ShieldCheck className="h-3.5 w-3.5 text-neon" /> Təhlükəsiz sifariş prosesi</span>
            <span className="h-4 w-px shrink-0 bg-border" />
            <Link to="/marketplace" className="shrink-0 font-black text-neon hover:underline">Yeni oyunları kəşf et →</Link>
          </>
        )}
      </div>
    </div>
  );
}
