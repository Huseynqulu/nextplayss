import { Link } from "@tanstack/react-router";
import { BadgeCheck, Flame, Heart, ShoppingCart, Star, Zap } from "lucide-react";
import { ProductCoverPlaceholder } from "@/components/ProductCoverPlaceholder";
import { imgUrl } from "@/lib/image-url";
import type { Product } from "@/lib/marketplace-data";
import { useFavorites, isRealProductId } from "@/lib/favorites";
import { useAuth } from "@/hooks/use-auth";
import { useCurrency } from "@/lib/currency";
import { useCart } from "@/lib/cart";
import { useT } from "@/lib/i18n";
import { toast } from "sonner";
import { MARKETPLACE_ENABLED, displaySellerName } from "@/lib/store-mode";

function formatSoldAgo(iso?: string | null): string | null {
  if (!iso) return null;
  const diffMs = Date.now() - new Date(iso).getTime();
  if (diffMs < 0) return null;
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "indicə satıldı";
  if (mins < 60) return `${mins} dəq əvvəl satıldı`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} saat əvvəl satıldı`;
  const days = Math.floor(hours / 24);
  if (days <= 14) return `${days} gün əvvəl satıldı`;
  return null;
}

export function ProductCard({ p, variant = "default" }: { p: Product; variant?: "default" | "compact" | "list" }) {
  const { format } = useCurrency();
  const t = useT();
  const discount = p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
  const { isFav, toggle } = useFavorites();
  const { user } = useAuth();
  const { add } = useCart();
  const canFav = !!user && isRealProductId(p.id);
  const canCart = isRealProductId(p.id) && p.stock > 0;
  const fav = canFav && isFav(p.id);
  const soldAgo = formatSoldAgo(p.lastSoldAt);
  const sellerRating = Number(p.seller.rating || p.rating || 0);
  const sellerReviews = p.seller.reviewsCount ?? p.reviews ?? 0;
  const sellerRatingText = sellerRating > 0 ? (Number.isInteger(sellerRating) ? String(sellerRating) : sellerRating.toFixed(1)) : null;

  function addToCart(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    add({ id: p.id, slug: p.slug, title: p.title, image: p.image, price: p.price, sellerName: p.seller.name, stock: p.stock });
    toast.success("Səbətə əlavə edildi");
  }

  if (variant === "list") {
    return (
      <Link
        to="/product/$slug"
        params={{ slug: p.slug }}
        className="group flex items-center gap-3 rounded-xl border border-border bg-card-gradient p-3 card-shadow transition hover:border-neon/45"
      >
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-3">
            <h3 className="line-clamp-2 break-words text-sm font-bold leading-snug transition group-hover:text-neon">{p.title}</h3>
            {p.delivery === "Instant" ? (
              <span className="inline-flex shrink-0 items-center gap-0.5 rounded border border-neon/30 bg-neon/10 px-1.5 py-0.5 text-[10px] font-bold text-neon">
                <Zap className="h-2.5 w-2.5" /> {t("product.delivery.instant")}
              </span>
            ) : (
              <span className="inline-flex shrink-0 items-center rounded border border-border bg-surface px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
                {t("product.delivery.manual")}
              </span>
            )}
          </div>
          <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
            <span>{p.platform}</span>
            <span>·</span>
            {(p.seller.verified || !MARKETPLACE_ENABLED) && <BadgeCheck className="h-3.5 w-3.5 fill-sky-500/25 text-sky-400" strokeWidth={2.5} />}
            <span className="max-w-[140px] truncate">{displaySellerName(p.seller.name)}</span>
            {sellerRating > 0 && (
              <>
                <span>·</span>
                <Star className="h-2.5 w-2.5 fill-warning text-warning" />
                <span>{sellerRatingText} ({sellerReviews})</span>
              </>
            )}
            {soldAgo && (
              <>
                <span>·</span>
                <span className="inline-flex items-center gap-1 text-orange-400"><Flame className="h-3 w-3" />{soldAgo}</span>
              </>
            )}
          </div>
        </div>
        <div className="flex shrink-0 flex-col items-end gap-1">
          <div className="flex items-baseline gap-2">
            <span className="font-display text-lg font-black text-neon">{format(p.price)}</span>
            {p.oldPrice && <span className="text-[11px] text-muted-foreground line-through">{format(p.oldPrice)}</span>}
          </div>
          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{p.stock} stok</span>
        </div>
      </Link>
    );
  }

  const isCompact = variant === "compact";

  return (
    <Link
      to="/product/$slug"
      params={{ slug: p.slug }}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-card card-shadow transition duration-300 hover:-translate-y-1 hover:border-neon/45"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-surface/40">
        {p.image ? (
          <img
            src={imgUrl(p.image, { width: 520, height: 390, quality: 78 })}
            alt={p.title}
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
          />
        ) : (
          <ProductCoverPlaceholder title={p.title} />
        )}

        <div className="absolute inset-x-0 top-0 flex items-start justify-between gap-2 p-2.5">
          <div className="flex flex-wrap gap-1.5">
            {discount > 0 && (
              <span className="rounded-lg bg-destructive px-2 py-1 text-[10px] font-black text-destructive-foreground shadow-lg">-{discount}%</span>
            )}
            {p.delivery === "Instant" && (
              <span className="inline-flex items-center gap-1 rounded-lg border border-neon/25 bg-background/85 px-2 py-1 text-[10px] font-black text-neon backdrop-blur">
                <Zap className="h-2.5 w-2.5" /> Anında
              </span>
            )}
          </div>

          {canFav && (
            <button
              type="button"
              aria-label={fav ? "İstək siyahısından çıxar" : "İstək siyahısına əlavə et"}
              onClick={(e) => {
                e.preventDefault();
                e.stopPropagation();
                toggle(p.id);
              }}
              className={`grid h-8 w-8 place-items-center rounded-lg border backdrop-blur transition ${fav ? "border-destructive/40 bg-destructive text-white" : "border-white/10 bg-background/80 text-foreground hover:text-neon"}`}
            >
              <Heart className={`h-4 w-4 ${fav ? "fill-current" : ""}`} />
            </button>
          )}
        </div>
      </div>

      <div className={`flex flex-1 flex-col ${isCompact ? "gap-2 p-3" : "gap-2.5 p-4"}`}>
        <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
          <span>{p.platform || "Rəqəmsal"}</span>
          {p.stock > 0 && <><span>·</span><span className="text-success">Stokda</span></>}
        </div>

        <h3 className={`${isCompact ? "text-sm" : "text-[15px] sm:text-base"} line-clamp-2 min-h-[2.6em] font-display font-bold leading-snug transition group-hover:text-neon`}>
          {p.title}
        </h3>

        <div className="flex min-h-5 items-center gap-1.5 text-[11px] text-muted-foreground">
          {(p.seller.verified || !MARKETPLACE_ENABLED) && <BadgeCheck className="h-3.5 w-3.5 shrink-0 fill-sky-500/20 text-sky-400" strokeWidth={2.4} />}
          <span className="max-w-[115px] truncate">{displaySellerName(p.seller.name)}</span>
          {sellerRating > 0 && (
            <>
              <span>·</span>
              <Star className="h-3 w-3 fill-warning text-warning" />
              <span>{sellerRatingText}</span>
            </>
          )}
        </div>

        <div className="mt-auto border-t border-border/70 pt-3">
          <div className="flex items-end justify-between gap-2">
            <div>
              {p.oldPrice && <div className="mb-0.5 text-[11px] text-muted-foreground line-through">{format(p.oldPrice)}</div>}
              <div className={`${isCompact ? "text-base" : "text-xl"} font-display font-black leading-none text-neon`}>{format(p.price)}</div>
            </div>
            {!canCart && <span className="text-[10px] font-bold text-muted-foreground">Stok yoxdur</span>}
          </div>

          {canCart && (
            <button
              type="button"
              onClick={addToCart}
              className={`mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-neon font-black text-background transition hover:opacity-90 ${isCompact ? "h-9 text-[11px]" : "h-10 text-xs"}`}
            >
              <ShoppingCart className="h-3.5 w-3.5" /> Səbətə əlavə et
            </button>
          )}
        </div>
      </div>
    </Link>
  );
}
