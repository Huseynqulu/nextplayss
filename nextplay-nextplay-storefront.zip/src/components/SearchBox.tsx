import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Gift, Loader2, Search } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrency } from "@/lib/currency";
import { trackSearch } from "@/lib/fbq";
import { imgUrl } from "@/lib/image-url";

type Hit = {
  id: string;
  title: string;
  slug: string;
  price: number;
  image_url: string | null;
  image_urls: string[] | null;
  platform?: string | null;
};

type GiftHit = {
  id: string;
  slug: string;
  name: string;
  logo_url: string | null;
};

export function SearchBox({ variant = "desktop" }: { variant?: "desktop" | "mobile" }) {
  const navigate = useNavigate();
  const { format } = useCurrency();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const [hits, setHits] = useState<Hit[]>([]);
  const [giftHits, setGiftHits] = useState<GiftHit[]>([]);
  const [loading, setLoading] = useState(false);
  const wrapRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  useEffect(() => {
    const term = q.trim();
    if (term.length < 2) {
      setHits([]);
      setGiftHits([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    const ctrl = new AbortController();
    const timer = setTimeout(async () => {
      const [prodRes, giftRes] = await Promise.all([
        supabase
          .from("products")
          .select("id,title,slug,price,image_url,image_urls,platform")
          .ilike("title", `%${term}%`)
          .is("gift_denomination_id", null)
          .eq("is_active", true)
          .gt("stock", 0)
          .order("created_at", { ascending: false })
          .limit(7)
          .abortSignal(ctrl.signal),
        supabase
          .from("gift_platforms" as any)
          .select("id,slug,name,logo_url")
          .ilike("name", `%${term}%`)
          .eq("is_active", true)
          .order("sort_order")
          .limit(4)
          .abortSignal(ctrl.signal),
      ]);

      setHits((prodRes.data as any) ?? []);
      setGiftHits((giftRes.data as any) ?? []);
      setLoading(false);
    }, 180);

    return () => {
      clearTimeout(timer);
      ctrl.abort();
    };
  }, [q]);

  function goToResults() {
    const term = q.trim();
    setOpen(false);
    trackSearch(term);
    navigate({ to: "/marketplace", search: term ? { q: term } : {} });
  }

  function submit(e: React.FormEvent) {
    e.preventDefault();
    goToResults();
  }

  const widthClass = variant === "desktop"
    ? "hidden md:flex min-w-0 flex-1 max-w-2xl"
    : "flex w-full";
  const hasResults = hits.length > 0 || giftHits.length > 0;

  return (
    <div ref={wrapRef} className={`${widthClass} relative`}>
      <form onSubmit={submit} className="relative w-full">
        <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <input
          value={q}
          onChange={(e) => {
            setQ(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          placeholder="Oyun, platforma, hədiyyə kartı axtar..."
          aria-label="Saytda axtar"
          autoComplete="off"
          className="h-11 w-full rounded-xl border border-border bg-surface/70 pl-11 pr-20 text-sm outline-none transition placeholder:text-muted-foreground/75 focus:border-neon/50 focus:bg-background focus:ring-2 focus:ring-neon/15"
        />
        <button
          type="submit"
          className="absolute right-1.5 top-1/2 hidden h-8 -translate-y-1/2 items-center rounded-lg bg-neon px-3 text-[11px] font-black text-background transition hover:opacity-90 sm:flex"
        >
          Axtar
        </button>
      </form>

      {open && q.trim().length >= 2 && (
        <div className="absolute left-0 right-0 top-[52px] z-50 max-h-[72vh] overflow-y-auto rounded-2xl border border-border bg-popover shadow-2xl card-shadow">
          {loading ? (
            <div className="flex items-center gap-2 px-5 py-5 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin text-neon" /> Axtarılır...
            </div>
          ) : !hasResults ? (
            <div className="px-5 py-8 text-center">
              <p className="text-sm font-bold">Nəticə tapılmadı</p>
              <p className="mt-1 text-xs text-muted-foreground">Başqa sözlə yoxla və ya bütün kataloqa keç.</p>
            </div>
          ) : (
            <>
              {giftHits.length > 0 && (
                <div className="border-b border-border p-2">
                  <div className="px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.16em] text-muted-foreground">Hədiyyə kartları</div>
                  <div className="grid gap-1 sm:grid-cols-2">
                    {giftHits.map((g) => (
                      <Link
                        key={g.id}
                        to="/gift-cards/$platform"
                        params={{ platform: g.slug }}
                        onClick={() => {
                          setOpen(false);
                          setQ("");
                        }}
                        className="flex items-center gap-3 rounded-xl px-2.5 py-2 hover:bg-neon/8 transition"
                      >
                        <div className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-lg border border-border bg-surface">
                          {g.logo_url ? <img src={g.logo_url} alt="" className="h-full w-full object-cover" /> : <Gift className="h-4 w-4 text-neon" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-bold">{g.name}</p>
                          <p className="text-[11px] text-muted-foreground">Hədiyyə kartlarına bax</p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              )}

              {hits.length > 0 && (
                <div className="p-2">
                  <div className="px-2 py-1.5 text-[10px] font-black uppercase tracking-[0.16em] text-muted-foreground">Məhsullar</div>
                  <div className="flex flex-col gap-1">
                    {hits.map((hit) => {
                      const image = hit.image_url || hit.image_urls?.[0] || null;
                      return (
                        <Link
                          key={hit.id}
                          to="/product/$slug"
                          params={{ slug: hit.slug }}
                          onClick={() => {
                            setOpen(false);
                            setQ("");
                          }}
                          className="flex items-center gap-3 rounded-xl px-2.5 py-2.5 transition hover:bg-surface"
                        >
                          <div className="h-12 w-10 shrink-0 overflow-hidden rounded-lg border border-border bg-surface">
                            {image ? <img src={imgUrl(image, { width: 96, height: 120, quality: 70 })} alt="" className="h-full w-full object-cover" /> : <div className="grid h-full place-items-center"><Search className="h-4 w-4 text-muted-foreground" /></div>}
                          </div>
                          <div className="min-w-0 flex-1">
                            <p className="line-clamp-1 text-sm font-bold">{hit.title}</p>
                            <p className="mt-0.5 text-[11px] text-muted-foreground">{hit.platform || "Rəqəmsal məhsul"}</p>
                          </div>
                          <span className="shrink-0 text-sm font-black text-neon">{format(hit.price)}</span>
                        </Link>
                      );
                    })}
                  </div>
                </div>
              )}

              <button onClick={goToResults} className="flex w-full items-center justify-center gap-2 border-t border-border px-4 py-3 text-xs font-black text-neon transition hover:bg-surface">
                “{q.trim()}” üçün bütün nəticələr <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
