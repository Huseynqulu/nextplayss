import { Link, useNavigate } from "@tanstack/react-router";
import {
  ChevronDown,
  Gamepad2,
  Gift,
  Heart,
  Headphones,
  LayoutDashboard,
  LifeBuoy,
  LogOut,
  Menu,
  MessageSquare,
  Monitor,
  Package,
  Percent,
  Plus,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  User as UserIcon,
  Wallet,
  X,
  Zap,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { supabase } from "@/integrations/supabase/client";
import { useT } from "@/lib/i18n";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { useOnlinePresence } from "@/lib/presence";
import { NotificationBell } from "@/components/NotificationBell";
import { SearchBox } from "@/components/SearchBox";
import { useCurrency } from "@/lib/currency";
import nextplayLogo from "@/assets/nextplay-logo.png";
import { imgUrl } from "@/lib/image-url";
import { MARKETPLACE_ENABLED } from "@/lib/store-mode";
import { ComingSoonSeller } from "@/components/ComingSoonSeller";
import { useCart } from "@/lib/cart";

const pcPlatforms = "PC,Steam,EA,Epic Games,Epic,Rockstar,Battle.net";
const psPlatforms = "PlayStation,PS5,PS4";

export function Header() {
  const t = useT();
  const { format } = useCurrency();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [catalogOpen, setCatalogOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const { user, signOut } = useAuth();
  useOnlinePresence();
  const navigate = useNavigate();
  const [roles, setRoles] = useState<string[]>([]);
  const [avatarUrl, setAvatarUrl] = useState<string | null>(null);
  const [displayLabel, setDisplayLabel] = useState<string | null>(null);
  const [balance, setBalance] = useState<number | null>(null);
  const [unreadDm, setUnreadDm] = useState(0);

  useEffect(() => {
    if (!user) {
      setRoles([]);
      setAvatarUrl(null);
      setUnreadDm(0);
      setDisplayLabel(null);
      setBalance(null);
      return;
    }

    supabase.from("user_roles").select("role").eq("user_id", user.id).then(({ data }) => {
      const nextRoles = (data ?? []).map((x: any) => x.role);
      setRoles(nextRoles);
      const hasSeller = nextRoles.includes("seller");

      supabase
        .from("profiles")
        .select("avatar_url,shop_name,username,display_name,wallet_balance")
        .eq("id", user.id)
        .maybeSingle()
        .then(({ data: profile }) => {
          const p = profile as any;
          setAvatarUrl(p?.avatar_url ?? null);
          setBalance(p?.wallet_balance != null ? Number(p.wallet_balance) : null);
          const label = hasSeller
            ? p?.shop_name || p?.username || p?.display_name
            : p?.username || p?.display_name;
          setDisplayLabel(label || null);
        });
    });

    const loadUnread = () => {
      supabase
        .from("dm_messages")
        .select("id", { count: "exact", head: true })
        .is("read_at", null)
        .neq("sender_id", user.id)
        .then(({ count }) => setUnreadDm(count ?? 0));
    };

    loadUnread();
    const channel = supabase
      .channel(`hdr-dm-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "dm_messages" }, loadUnread)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "profiles", filter: `id=eq.${user.id}` }, (payload: any) => {
        const nextBalance = payload?.new?.wallet_balance;
        if (nextBalance != null) setBalance(Number(nextBalance));
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const isAdmin = roles.includes("admin");
  const isSeller = roles.includes("seller");
  const isSupport = roles.includes("support");

  async function handleSignOut() {
    await signOut();
    setMenuOpen(false);
    navigate({ to: "/" });
  }

  return (
    <header className="sticky top-0 z-50 border-b border-border/70 bg-background/92 backdrop-blur-xl">
      <div className="border-b border-border/50 bg-surface/55">
        <div className="mx-auto flex h-8 max-w-[1440px] items-center justify-between gap-4 px-4 text-[11px] text-muted-foreground sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 overflow-hidden whitespace-nowrap">
            <Zap className="h-3.5 w-3.5 shrink-0 text-neon" />
            <span className="truncate">Rəqəmsal oyunlar və məhsullar · sürətli, rahat və təhlükəsiz alış</span>
          </div>
          <div className="hidden items-center gap-5 md:flex">
            <Link to="/support" className="hover:text-foreground transition">Dəstək</Link>
            <Link to="/user-guide" className="hover:text-foreground transition">Alış bələdçisi</Link>
            <LanguageSwitcher />
          </div>
        </div>
      </div>

      <div className="mx-auto flex min-h-[76px] max-w-[1440px] items-center gap-3 px-4 sm:px-6 lg:px-8">
        <Link to="/" aria-label="NextPlay ana səhifə" className="group shrink-0">
          <img
            src={nextplayLogo}
            alt="NextPlay"
            className="h-11 w-auto transition group-hover:drop-shadow-[0_0_18px_hsl(var(--neon)/0.45)] sm:h-12"
          />
        </Link>

        <div className="relative hidden lg:block">
          <button
            type="button"
            onClick={() => setCatalogOpen((v) => !v)}
            className={`flex h-11 items-center gap-2 rounded-xl border px-4 text-sm font-bold transition ${
              catalogOpen
                ? "border-neon/50 bg-neon/10 text-neon"
                : "border-border bg-surface/70 hover:border-neon/30 hover:bg-surface"
            }`}
          >
            <Menu className="h-4 w-4" />
            Kataloq
            <ChevronDown className={`h-4 w-4 transition ${catalogOpen ? "rotate-180" : ""}`} />
          </button>

          {catalogOpen && (
            <>
              <button className="fixed inset-0 z-10 cursor-default" aria-label="Kataloqu bağla" onClick={() => setCatalogOpen(false)} />
              <div className="absolute left-0 top-14 z-20 w-[760px] overflow-hidden rounded-2xl border border-border bg-popover shadow-2xl card-shadow">
                <div className="grid grid-cols-3 gap-0">
                  <CatalogGroup icon={Gamepad2} title="PlayStation" subtitle="PS4 və PS5">
                    <CatalogLink label="Bütün PlayStation oyunları" search={{ platforms: psPlatforms }} onClick={() => setCatalogOpen(false)} />
                    <CatalogLink label="PS5 oyunları" search={{ platform: "PS5" }} onClick={() => setCatalogOpen(false)} />
                    <CatalogLink label="PS4 oyunları" search={{ platform: "PS4" }} onClick={() => setCatalogOpen(false)} />
                    <CatalogLink label="PlayStation hesabları" search={{ cat: "Accounts", platforms: psPlatforms }} onClick={() => setCatalogOpen(false)} />
                  </CatalogGroup>

                  <CatalogGroup icon={Monitor} title="PC oyunları" subtitle="Steam və PC platformaları">
                    <CatalogLink label="Bütün PC oyunları" search={{ platforms: pcPlatforms, cat: "Games" }} onClick={() => setCatalogOpen(false)} />
                    <CatalogLink label="Steam oyunları" search={{ platform: "Steam" }} onClick={() => setCatalogOpen(false)} />
                    <CatalogLink label="Oyun açarları" search={{ cat: "Keys", platforms: pcPlatforms }} onClick={() => setCatalogOpen(false)} />
                    <CatalogLink label="PC hesabları" search={{ cat: "Accounts", platforms: pcPlatforms }} onClick={() => setCatalogOpen(false)} />
                  </CatalogGroup>

                  <div className="bg-neon/[0.045] p-5">
                    <p className="mb-3 text-xs font-black uppercase tracking-[0.18em] text-neon">Rəqəmsal məhsullar</p>
                    <div className="space-y-1">
                      <Link to="/gift-cards" onClick={() => setCatalogOpen(false)} className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold hover:bg-neon/10 transition">
                        <Gift className="h-4 w-4 text-neon" /> Hədiyyə kartları
                      </Link>
                      <Link to="/wallet" onClick={() => setCatalogOpen(false)} className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold hover:bg-neon/10 transition">
                        <Wallet className="h-4 w-4 text-neon" /> Balansı artır
                      </Link>
                      <Link to="/marketplace" search={{ sort: "low" } as any} onClick={() => setCatalogOpen(false)} className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold hover:bg-neon/10 transition">
                        <Percent className="h-4 w-4 text-neon" /> Sərfəli təkliflər
                      </Link>
                      <Link to="/support" onClick={() => setCatalogOpen(false)} className="flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-semibold hover:bg-neon/10 transition">
                        <Headphones className="h-4 w-4 text-neon" /> Dəstək mərkəzi
                      </Link>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-border bg-surface/50 px-5 py-3 text-xs">
                  <span className="text-muted-foreground">Axtardığını tapmadın?</span>
                  <Link to="/marketplace" onClick={() => setCatalogOpen(false)} className="font-bold text-neon hover:underline">
                    Bütün kataloqa bax →
                  </Link>
                </div>
              </div>
            </>
          )}
        </div>

        <SearchBox variant="desktop" />

        <div className="ml-auto flex items-center gap-1.5 sm:gap-2">
          {user && balance !== null && (
            <div className="hidden xl:inline-flex items-stretch overflow-hidden rounded-xl border border-neon/30 bg-neon/10">
              <Link to="/wallet" className="flex h-10 items-center gap-1.5 px-3 text-sm font-semibold hover:bg-neon/15 transition" title="Cüzdan">
                <Wallet className="h-4 w-4 text-neon" />
                <span className="tabular-nums">{format(balance)}</span>
              </Link>
              <Link to="/wallet" className="grid h-10 place-items-center border-l border-neon/30 bg-neon px-2 text-background" aria-label="Balansı artır">
                <Plus className="h-4 w-4" />
              </Link>
            </div>
          )}

          <div className="hidden sm:block"><CartButton /></div>

          {user && (
            <Link to="/messages" className="relative hidden h-10 w-10 place-items-center rounded-xl hover:bg-surface md:grid" aria-label="Mesajlar">
              <MessageSquare className="h-5 w-5" />
              {unreadDm > 0 && (
                <span className="absolute -right-1 -top-1 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-neon px-1 text-[10px] font-bold leading-none text-background">
                  {unreadDm > 99 ? "99+" : unreadDm}
                </span>
              )}
            </Link>
          )}

          <div className="hidden md:block"><NotificationBell /></div>

          {user ? (
            <div className="relative">
              <button
                onClick={() => setMenuOpen(!menuOpen)}
                className="flex h-10 items-center gap-2 rounded-xl border border-border px-2.5 hover:bg-surface transition"
              >
                <div className="grid h-7 w-7 place-items-center overflow-hidden rounded-full bg-neon text-xs font-bold text-background">
                  {avatarUrl ? (
                    <img src={imgUrl(avatarUrl, { width: 56, height: 56, quality: 70 })} alt="" loading="lazy" decoding="async" className="h-full w-full object-cover" />
                  ) : (
                    (user.user_metadata?.display_name ?? user.email ?? "U")[0].toUpperCase()
                  )}
                </div>
                <span className="hidden max-w-[120px] truncate text-sm font-semibold xl:inline">
                  {displayLabel ?? user.user_metadata?.display_name ?? user.email?.split("@")[0]}
                </span>
                <ChevronDown className="hidden h-3.5 w-3.5 text-muted-foreground xl:block" />
              </button>

              {menuOpen && (
                <>
                  <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
                  <div className="absolute right-0 top-12 z-20 w-60 overflow-hidden rounded-2xl border border-border bg-popover shadow-xl card-shadow">
                    <div className="border-b border-border px-4 py-3">
                      <p className="text-xs text-muted-foreground">{t("auth.signedIn")}</p>
                      <p className="truncate text-sm font-semibold">{user.email}</p>
                    </div>
                    <AccountLink to="/profile" icon={UserIcon} label={t("menu.profile")} close={() => setMenuOpen(false)} />
                    <AccountLink to="/orders" icon={ShoppingBag} label={t("menu.orders")} close={() => setMenuOpen(false)} />
                    <AccountLink to="/wallet" icon={Wallet} label="Cüzdan" close={() => setMenuOpen(false)} suffix={balance !== null ? format(balance) : undefined} />
                    <AccountLink to="/messages" icon={MessageSquare} label="Mesajlar" close={() => setMenuOpen(false)} />
                    <AccountLink to="/favorites" icon={Heart} label="İstək siyahım" close={() => setMenuOpen(false)} />
                    <AccountLink to="/referrals" icon={Gift} label="Referal proqramı" close={() => setMenuOpen(false)} />
                    <AccountLink to="/support-tickets" icon={LifeBuoy} label="Dəstək müraciətlərim" close={() => setMenuOpen(false)} />

                    {MARKETPLACE_ENABLED ? (
                      <AccountLink to="/seller" icon={LayoutDashboard} label={t("menu.becomeSeller")} close={() => setMenuOpen(false)} />
                    ) : (
                      <div className="flex items-center gap-2 px-4 py-2.5 text-sm">
                        <LayoutDashboard className="h-4 w-4 opacity-70" />
                        <ComingSoonSeller label={t("menu.becomeSeller")} />
                      </div>
                    )}

                    {isSeller && (
                      <>
                        <AccountLink to="/seller-dashboard" icon={Package} label={t("menu.myProducts")} close={() => setMenuOpen(false)} />
                        <Link to="/seller-orders" search={{ open: undefined }} onClick={() => setMenuOpen(false)} className="flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-surface transition">
                          <ShoppingBag className="h-4 w-4" /> Gələn sifarişlər
                        </Link>
                      </>
                    )}

                    {(isSupport || isAdmin) && <AccountLink to="/staff" icon={LifeBuoy} label="Dəstək Paneli" close={() => setMenuOpen(false)} accent />}
                    {isAdmin && <AccountLink to="/admin" icon={ShieldCheck} label={t("menu.admin")} close={() => setMenuOpen(false)} accent />}

                    <button onClick={handleSignOut} className="flex w-full items-center gap-2 px-4 py-2.5 text-sm text-destructive hover:bg-surface transition">
                      <LogOut className="h-4 w-4" /> {t("menu.signOut")}
                    </button>
                  </div>
                </>
              )}
            </div>
          ) : (
            <div className="hidden items-center gap-2 sm:flex">
              <Link to="/login" className="inline-flex h-10 items-center rounded-xl border border-border px-3 text-sm font-semibold hover:bg-surface transition">
                Giriş
              </Link>
              <Link to="/register" className="inline-flex h-10 items-center rounded-xl bg-neon px-4 text-sm font-black text-background hover:opacity-95 transition">
                Qeydiyyat
              </Link>
            </div>
          )}

          <button onClick={() => setMobileOpen((v) => !v)} className="grid h-10 w-10 place-items-center rounded-xl hover:bg-surface lg:hidden" aria-label="Menyu">
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      <div className="border-t border-border/50 lg:hidden">
        <div className="mx-auto max-w-[1440px] px-4 py-2 sm:px-6">
          <SearchBox variant="mobile" />
        </div>
      </div>

      <nav className="hidden border-t border-border/50 bg-background/75 lg:block">
        <div className="mx-auto flex h-11 max-w-[1440px] items-center gap-1 px-4 sm:px-6 lg:px-8">
          <QuickNav label="Ana səhifə" to="/" />
          <QuickNav label="PlayStation" to="/marketplace" search={{ platforms: psPlatforms }} />
          <QuickNav label="PC Oyunları" to="/marketplace" search={{ platforms: pcPlatforms, cat: "Games" }} />
          <QuickNav label="Steam" to="/marketplace" search={{ platform: "Steam" }} />
          <QuickNav label="Hədiyyə kartları" to="/gift-cards" />
          <QuickNav label="Endirimlər" to="/marketplace" search={{ sort: "low" }} />
          <QuickNav label="Dəstək" to="/support" />
          {MARKETPLACE_ENABLED ? (
            <QuickNav label="Satıcı ol" to="/seller" className="ml-auto" />
          ) : (
            <div className="ml-auto"><ComingSoonSeller label="Satıcı ol" className="px-3 py-2 text-xs font-bold text-muted-foreground" /></div>
          )}
        </div>
      </nav>

      {mobileOpen && (
        <div className="border-t border-border bg-background/98 backdrop-blur lg:hidden">
          <div className="mx-auto max-w-[1440px] px-4 py-4 sm:px-6">
            <div className="grid grid-cols-2 gap-2">
              <MobileNavCard icon={Gamepad2} title="PlayStation" subtitle="PS4 · PS5" to="/marketplace" search={{ platforms: psPlatforms }} close={() => setMobileOpen(false)} />
              <MobileNavCard icon={Monitor} title="PC Oyunları" subtitle="Steam · EA · Epic" to="/marketplace" search={{ platforms: pcPlatforms }} close={() => setMobileOpen(false)} />
              <MobileNavCard icon={Gift} title="Hədiyyə kartları" subtitle="Rəqəmsal kodlar" to="/gift-cards" close={() => setMobileOpen(false)} />
              <MobileNavCard icon={Wallet} title="Balans" subtitle="Balansı artır" to="/wallet" close={() => setMobileOpen(false)} />
            </div>
            <div className="mt-3 grid gap-1 border-t border-border pt-3">
              <Link to="/marketplace" onClick={() => setMobileOpen(false)} className="rounded-lg px-3 py-2.5 text-sm font-semibold hover:bg-surface">Bütün məhsullar</Link>
              <Link to="/support" onClick={() => setMobileOpen(false)} className="rounded-lg px-3 py-2.5 text-sm font-semibold hover:bg-surface">Dəstək</Link>
              <div className="flex items-center justify-between rounded-lg px-3 py-2">
                <span className="text-sm font-semibold">Dil</span>
                <LanguageSwitcher />
              </div>
              {!user && (
                <div className="mt-2 grid grid-cols-2 gap-2">
                  <Link to="/login" onClick={() => setMobileOpen(false)} className="grid h-10 place-items-center rounded-xl border border-border text-sm font-bold">Giriş</Link>
                  <Link to="/register" onClick={() => setMobileOpen(false)} className="grid h-10 place-items-center rounded-xl bg-neon text-sm font-black text-background">Qeydiyyat</Link>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </header>
  );
}

function CatalogGroup({ icon: Icon, title, subtitle, children }: { icon: any; title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="border-r border-border p-5 last:border-r-0">
      <div className="mb-4 flex items-center gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-neon/10 text-neon"><Icon className="h-5 w-5" /></div>
        <div>
          <p className="font-black">{title}</p>
          <p className="text-[11px] text-muted-foreground">{subtitle}</p>
        </div>
      </div>
      <div className="space-y-1">{children}</div>
    </div>
  );
}

function CatalogLink({ label, search, onClick }: { label: string; search: Record<string, any>; onClick: () => void }) {
  return (
    <Link to="/marketplace" search={search as any} onClick={onClick} className="block rounded-lg px-3 py-2.5 text-sm text-muted-foreground hover:bg-surface hover:text-foreground transition">
      {label}
    </Link>
  );
}

function QuickNav({ label, to, search, className = "" }: { label: string; to: any; search?: Record<string, any>; className?: string }) {
  return (
    <Link to={to} search={search as any} className={`rounded-lg px-3 py-2 text-xs font-bold text-muted-foreground transition hover:bg-surface hover:text-foreground ${className}`}>
      {label}
    </Link>
  );
}

function MobileNavCard({ icon: Icon, title, subtitle, to, search, close }: { icon: any; title: string; subtitle: string; to: any; search?: Record<string, any>; close: () => void }) {
  return (
    <Link to={to} search={search as any} onClick={close} className="rounded-2xl border border-border bg-card p-4 hover:border-neon/40 transition">
      <Icon className="mb-3 h-5 w-5 text-neon" />
      <p className="text-sm font-black">{title}</p>
      <p className="mt-0.5 text-[11px] text-muted-foreground">{subtitle}</p>
    </Link>
  );
}

function AccountLink({ to, icon: Icon, label, close, suffix, accent = false }: { to: any; icon: any; label: string; close: () => void; suffix?: string; accent?: boolean }) {
  return (
    <Link to={to} onClick={close} className={`flex items-center gap-2 px-4 py-2.5 text-sm hover:bg-surface transition ${accent ? "text-neon" : ""}`}>
      <Icon className="h-4 w-4" />
      <span>{label}</span>
      {suffix && <span className="ml-auto text-xs font-semibold text-neon">{suffix}</span>}
    </Link>
  );
}

function CartButton() {
  const { count } = useCart();
  return (
    <Link to="/cart" className="relative grid h-10 w-10 place-items-center rounded-xl border border-border hover:bg-surface transition" aria-label="Səbət">
      <ShoppingCart className="h-5 w-5" />
      {count > 0 && (
        <span className="absolute -right-1 -top-1 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-neon px-1 text-[10px] font-bold text-background">
          {count > 99 ? "99+" : count}
        </span>
      )}
    </Link>
  );
}
