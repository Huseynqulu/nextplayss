import { useMemo, useState } from "react";
import { ArrowLeft, ArrowRight, Gamepad2, Monitor, RotateCcw, Sparkles } from "lucide-react";
import { fetchProducts } from "@/lib/products";
import type { Product } from "@/lib/marketplace-data";
import { ProductCard } from "@/components/ProductCard";

const pcPlatforms = new Set(["pc", "steam", "ea", "epic games", "epic", "rockstar", "battle.net"]);
const psPlatforms = new Set(["playstation", "ps5", "ps4"]);

const genreOptions = [
  { id: "action", label: "Aksiyon", words: ["action", "aksiyon", "döyüş", "combat"] },
  { id: "shooter", label: "Nişançı", words: ["shooter", "fps", "shoot", "call of duty", "battlefield"] },
  { id: "sports", label: "İdman", words: ["sport", "football", "fifa", "fc ", "nba", "wwe"] },
  { id: "racing", label: "Yarış", words: ["racing", "race", "forza", "need for speed", "f1 "] },
  { id: "rpg", label: "RPG", words: ["rpg", "role-playing", "elden", "witcher", "souls"] },
  { id: "horror", label: "Qorxu", words: ["horror", "resident evil", "outlast", "silent hill"] },
  { id: "strategy", label: "Strategiya", words: ["strategy", "strategiya", "civilization", "manager"] },
  { id: "surprise", label: "Məni təəccübləndir", words: [] },
] as const;

const budgetOptions = [
  { value: 15, label: "15 ₼-dək", caption: "Sərfəli" },
  { value: 30, label: "30 ₼-dək", caption: "Populyar seçim" },
  { value: 60, label: "60 ₼-dək", caption: "Geniş seçim" },
  { value: 0, label: "Fərq etməz", caption: "Limit yoxdur" },
] as const;

type GenreId = (typeof genreOptions)[number]["id"];

export function GameFinder() {
  const [step, setStep] = useState(1);
  const [platform, setPlatform] = useState<"pc" | "playstation" | null>(null);
  const [genre, setGenre] = useState<GenreId | null>(null);
  const [budget, setBudget] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Product[]>([]);
  const [error, setError] = useState(false);

  const selectedGenre = useMemo(() => genreOptions.find((g) => g.id === genre), [genre]);

  async function loadRecommendations(nextBudget: number, shuffle = false) {
    if (!platform || !genre) return;
    setLoading(true);
    setError(false);

    try {
      const products = await fetchProducts();
      let pool = products.filter((product) => {
        if (product.category !== "Games") return false;
        const platformKey = (product.platform || "").toLowerCase();
        const matchesPlatform = platform === "pc" ? pcPlatforms.has(platformKey) : psPlatforms.has(platformKey);
        if (!matchesPlatform) return false;
        if (nextBudget > 0 && product.price > nextBudget) return false;
        return true;
      });

      const selected = genreOptions.find((item) => item.id === genre);
      if (selected && selected.words.length > 0) {
        const genreMatches = pool.filter((product) => {
          const text = `${product.title} ${product.description || ""}`.toLowerCase();
          return selected.words.some((word) => text.includes(word));
        });
        if (genreMatches.length >= 2) pool = genreMatches;
      }

      pool.sort((a, b) => {
        if (shuffle || genre === "surprise") return Math.random() - 0.5;
        const aScore = (a.rating || 0) * 10 + (a.reviews || 0) + (a.oldPrice ? 8 : 0);
        const bScore = (b.rating || 0) * 10 + (b.reviews || 0) + (b.oldPrice ? 8 : 0);
        return bScore - aScore;
      });

      setResults(pool.slice(0, 4));
    } catch {
      setError(true);
      setResults([]);
    } finally {
      setLoading(false);
      setStep(4);
    }
  }

  function chooseBudget(value: number) {
    setBudget(value);
    void loadRecommendations(value);
  }

  function reset() {
    setPlatform(null);
    setGenre(null);
    setBudget(null);
    setResults([]);
    setError(false);
    setStep(1);
  }

  return (
    <section className="mx-auto max-w-[1440px] px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
      <div className="overflow-hidden rounded-[28px] border border-border bg-card shadow-[0_24px_80px_-50px_hsl(var(--neon)/0.45)]">
        <div className="grid lg:grid-cols-[340px_1fr]">
          <div className="relative overflow-hidden border-b border-border bg-gradient-to-br from-primary/18 via-neon/8 to-transparent p-6 lg:border-b-0 lg:border-r lg:p-8">
            <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-neon/10 blur-3xl" />
            <div className="relative">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-neon/25 bg-neon/8 px-3 py-1 text-[10px] font-black uppercase tracking-[0.18em] text-neon">
                <Sparkles className="h-3.5 w-3.5" /> NextPlay Oyun Motoru
              </div>
              <h2 className="font-display text-3xl font-black leading-tight">Nə oynayacağını bilmirsən?</h2>
              <p className="mt-3 text-sm leading-6 text-muted-foreground">3 seçim et. Mövcud kataloqdan platformana və büdcənə uyğun oyunları çıxaraq.</p>

              <div className="mt-8 flex items-center gap-2">
                {[1, 2, 3].map((item) => (
                  <div key={item} className={`h-1.5 rounded-full transition-all ${step >= item ? "w-9 bg-neon" : "w-5 bg-border"}`} />
                ))}
              </div>
              <p className="mt-2 text-[11px] font-bold text-muted-foreground">{step <= 3 ? `${step}/3 addım` : "Seçim hazırdır"}</p>
            </div>
          </div>

          <div className="p-5 sm:p-7 lg:p-8">
            {step === 1 && (
              <div>
                <p className="text-xs font-black uppercase tracking-[0.16em] text-muted-foreground">Addım 1</p>
                <h3 className="mt-2 text-xl font-black sm:text-2xl">Harada oynayırsan?</h3>
                <div className="mt-6 grid gap-3 sm:grid-cols-2">
                  <ChoiceCard icon={Monitor} title="PC" subtitle="Steam, EA, Epic və digər PC platformaları" active={platform === "pc"} onClick={() => { setPlatform("pc"); setStep(2); }} />
                  <ChoiceCard icon={Gamepad2} title="PlayStation" subtitle="PS4 və PS5 oyunları" active={platform === "playstation"} onClick={() => { setPlatform("playstation"); setStep(2); }} />
                </div>
              </div>
            )}

            {step === 2 && (
              <div>
                <StepBack onClick={() => setStep(1)} />
                <p className="text-xs font-black uppercase tracking-[0.16em] text-muted-foreground">Addım 2</p>
                <h3 className="mt-2 text-xl font-black sm:text-2xl">Hansı janrı sevirsən?</h3>
                <div className="mt-6 grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {genreOptions.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => { setGenre(item.id); setStep(3); }}
                      className={`min-h-12 rounded-xl border px-3 py-2 text-sm font-bold transition hover:border-neon/45 hover:bg-neon/5 ${genre === item.id ? "border-neon bg-neon/10 text-neon" : "border-border bg-surface/50"}`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {step === 3 && (
              <div>
                <StepBack onClick={() => setStep(2)} />
                <p className="text-xs font-black uppercase tracking-[0.16em] text-muted-foreground">Addım 3</p>
                <h3 className="mt-2 text-xl font-black sm:text-2xl">Büdcən nə qədərdir?</h3>
                <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
                  {budgetOptions.map((item) => (
                    <button
                      key={item.label}
                      disabled={loading}
                      onClick={() => chooseBudget(item.value)}
                      className={`rounded-xl border p-4 text-left transition hover:border-neon/45 hover:bg-neon/5 disabled:opacity-50 ${budget === item.value ? "border-neon bg-neon/10" : "border-border bg-surface/50"}`}
                    >
                      <p className="font-black">{item.label}</p>
                      <p className="mt-1 text-[11px] text-muted-foreground">{item.caption}</p>
                    </button>
                  ))}
                </div>
                {loading && <p className="mt-5 text-sm font-semibold text-neon">Kataloqdan uyğun oyunlar seçilir...</p>}
              </div>
            )}

            {step === 4 && (
              <div>
                <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
                  <div>
                    <p className="text-xs font-black uppercase tracking-[0.16em] text-neon">Sənə uyğun seçimlər</p>
                    <h3 className="mt-2 text-xl font-black sm:text-2xl">NextPlay bunları tövsiyə edir</h3>
                    <p className="mt-1 text-sm text-muted-foreground">{platform === "pc" ? "PC" : "PlayStation"} · {selectedGenre?.label} · {budget ? `${budget} ₼-dək` : "büdcə limiti yoxdur"}</p>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => void loadRecommendations(budget ?? 0, true)} className="inline-flex h-10 items-center gap-2 rounded-xl border border-border px-4 text-xs font-black hover:bg-surface transition">
                      <RotateCcw className="h-3.5 w-3.5" /> Başqa seçim
                    </button>
                    <button onClick={reset} className="inline-flex h-10 items-center rounded-xl bg-neon px-4 text-xs font-black text-background hover:opacity-90 transition">Yenidən başla</button>
                  </div>
                </div>

                {error ? (
                  <div className="mt-6 rounded-2xl border border-destructive/30 bg-destructive/5 p-6 text-sm">Oyunlar yüklənərkən xəta baş verdi. Yenidən cəhd et.</div>
                ) : results.length > 0 ? (
                  <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
                    {results.map((product) => <ProductCard key={product.id} p={product} variant="compact" />)}
                  </div>
                ) : (
                  <div className="mt-6 rounded-2xl border border-dashed border-border bg-surface/35 p-8 text-center">
                    <p className="font-black">Bu seçimə uyğun məhsul tapılmadı.</p>
                    <p className="mt-1 text-sm text-muted-foreground">Büdcəni və ya janrı dəyişərək yenidən yoxla.</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}

function ChoiceCard({ icon: Icon, title, subtitle, active, onClick }: { icon: any; title: string; subtitle: string; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`group rounded-2xl border p-5 text-left transition hover:-translate-y-0.5 hover:border-neon/45 ${active ? "border-neon bg-neon/10" : "border-border bg-surface/45"}`}>
      <div className="grid h-12 w-12 place-items-center rounded-xl bg-neon/10 text-neon"><Icon className="h-6 w-6" /></div>
      <p className="mt-5 text-lg font-black">{title}</p>
      <p className="mt-1 text-xs leading-5 text-muted-foreground">{subtitle}</p>
      <div className="mt-4 inline-flex items-center gap-1 text-xs font-black text-neon">Seç <ArrowRight className="h-3.5 w-3.5 transition group-hover:translate-x-1" /></div>
    </button>
  );
}

function StepBack({ onClick }: { onClick: () => void }) {
  return (
    <button onClick={onClick} className="mb-4 inline-flex items-center gap-1 text-xs font-bold text-muted-foreground hover:text-foreground transition">
      <ArrowLeft className="h-3.5 w-3.5" /> Geri
    </button>
  );
}
