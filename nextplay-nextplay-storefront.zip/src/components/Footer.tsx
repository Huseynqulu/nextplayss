import { Link } from "@tanstack/react-router";
import { Headphones, ShieldCheck, Zap } from "lucide-react";
import nextplayLogo from "@/assets/nextplay-logo.png";
import { MARKETPLACE_ENABLED } from "@/lib/store-mode";
import { ComingSoonSeller } from "@/components/ComingSoonSeller";

const pcPlatforms = "PC,Steam,EA,Epic Games,Epic,Rockstar,Battle.net";
const psPlatforms = "PlayStation,PS5,PS4";

export function Footer() {
  return (
    <footer className="mt-20 border-t border-border bg-surface/40">
      <div className="mx-auto max-w-[1440px] px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-[1.3fr_1fr_1fr_1fr]">
          <div>
            <Link to="/" className="inline-flex items-center mb-4">
              <img src={nextplayLogo} alt="NextPlay.az" className="h-11 w-auto" />
            </Link>
            <p className="max-w-sm text-sm leading-6 text-muted-foreground">
              PlayStation və PC oyunları, hədiyyə kartları və rəqəmsal məhsulları bir məkanda kəşf et.
            </p>
            <div className="mt-5 grid max-w-sm gap-2 text-xs text-muted-foreground sm:grid-cols-3">
              <TrustMini icon={ShieldCheck} label="Təhlükəsiz alış" />
              <TrustMini icon={Zap} label="Sürətli çatdırılma" />
              <TrustMini icon={Headphones} label="Dəstək" />
            </div>
          </div>

          <div>
            <FooterTitle>Kataloq</FooterTitle>
            <FooterList>
              <li><Link to="/marketplace" className="footer-link">Bütün məhsullar</Link></li>
              <li><Link to="/marketplace" search={{ platforms: psPlatforms } as any} className="footer-link">PlayStation</Link></li>
              <li><Link to="/marketplace" search={{ platforms: pcPlatforms, cat: "Games" } as any} className="footer-link">PC Oyunları</Link></li>
              <li><Link to="/marketplace" search={{ platform: "Steam" } as any} className="footer-link">Steam</Link></li>
              <li><Link to="/gift-cards" className="footer-link">Hədiyyə kartları</Link></li>
            </FooterList>
          </div>

          <div>
            <FooterTitle>Müştərilər üçün</FooterTitle>
            <FooterList>
              <li><Link to="/user-guide" className="footer-link">Alış bələdçisi</Link></li>
              <li><Link to="/support" className="footer-link">Dəstək mərkəzi</Link></li>
              <li><Link to="/orders" className="footer-link">Sifarişlərim</Link></li>
              <li><Link to="/favorites" className="footer-link">İstək siyahım</Link></li>
              <li><Link to="/wallet" className="footer-link">Balans artır</Link></li>
            </FooterList>
          </div>

          <div>
            <FooterTitle>NextPlay</FooterTitle>
            <FooterList>
              <li><Link to="/login" className="footer-link">Giriş</Link></li>
              <li><Link to="/register" className="footer-link">Qeydiyyat</Link></li>
              <li>
                {MARKETPLACE_ENABLED ? (
                  <Link to="/seller" className="footer-link">Satıcı ol</Link>
                ) : (
                  <ComingSoonSeller label="Satıcı ol" className="footer-link" />
                )}
              </li>
              <li><Link to="/referrals" className="footer-link">Referal proqramı</Link></li>
            </FooterList>
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-5 border-t border-border pt-7 lg:flex-row lg:items-center lg:justify-between">
          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} NextPlay.az — Bütün hüquqlar qorunur.</p>
          <div className="flex flex-wrap gap-x-6 gap-y-2 text-xs text-muted-foreground">
            <Link to="/terms" className="hover:text-foreground transition">İstifadə şərtləri</Link>
            <Link to="/privacy" className="hover:text-foreground transition">Məxfilik</Link>
            <Link to="/refund" className="hover:text-foreground transition">İadə qaydaları</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterTitle({ children }: { children: React.ReactNode }) {
  return <h4 className="mb-4 text-sm font-black">{children}</h4>;
}

function FooterList({ children }: { children: React.ReactNode }) {
  return <ul className="space-y-2.5 text-sm [&_.footer-link]:text-muted-foreground [&_.footer-link]:transition [&_.footer-link:hover]:text-neon">{children}</ul>;
}

function TrustMini({ icon: Icon, label }: { icon: any; label: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <Icon className="h-3.5 w-3.5 text-neon" />
      <span>{label}</span>
    </div>
  );
}
