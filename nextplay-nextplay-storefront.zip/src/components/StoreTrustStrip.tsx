import { BadgeCheck, Headphones, ShieldCheck, Zap } from "lucide-react";

const items = [
  { icon: Zap, title: "Sürətli çatdırılma", text: "Uyğun məhsullarda gözləmədən təhvil" },
  { icon: ShieldCheck, title: "Təhlükəsiz alış", text: "Hesab və sifariş axını qorunur" },
  { icon: BadgeCheck, title: "Seçilmiş məhsullar", text: "Aktiv stok və aydın məhsul məlumatı" },
  { icon: Headphones, title: "Dəstək", text: "Sifarişdən əvvəl və sonra kömək" },
];

export function StoreTrustStrip() {
  return (
    <section className="border-y border-border/70 bg-surface/35">
      <div className="mx-auto grid max-w-[1440px] grid-cols-2 gap-px px-4 sm:px-6 lg:grid-cols-4 lg:px-8">
        {items.map(({ icon: Icon, title, text }, index) => (
          <div key={title} className={`flex items-start gap-3 py-5 ${index % 2 === 0 ? "pr-3" : "pl-3"} lg:px-5 first:lg:pl-0 last:lg:pr-0`}>
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-neon/10 text-neon"><Icon className="h-4 w-4" /></div>
            <div>
              <p className="text-xs font-black sm:text-sm">{title}</p>
              <p className="mt-0.5 text-[10px] leading-4 text-muted-foreground sm:text-[11px]">{text}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
