import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { ArrowRight, Flame, Sparkles, Tag, TimerReset } from "lucide-react";
import { fetchProducts } from "@/lib/products";
import type { Product } from "@/lib/marketplace-data";
import { ProductCard } from "./ProductCard";

const tabs = [
  { id: "featured", label: "Önə çıxanlar", icon: Sparkles },
  { id: "popular", label: "Çox seçilənlər", icon: Flame },
  { id: "deals", label: "Endirimlilər", icon: Tag },
  { id: "new", label: "Son əlavə olunanlar", icon: TimerReset },
] as const;

type TabId = (typeof tabs)[number]["id"];

export function SelectedProducts() {
  const [tab, setTab] = useState<TabId>("featured");

  const { data: products = [], isLoading } = useQuery({
    queryKey: ["homepage-store-products"],
    queryFn: fetchProducts,
  });

  const visible = useMemo(() => {
    const list = [...products];

    if (tab === "deals") {
      return list
        .filter((p) => Number(p.oldPrice || 0) > Number(p.price || 0))
        .sort((a, b) => discountPercent(b) - discountPercent(a))
        .slice(0, 8);
    }

    if (tab === "popular") {
      return list
        .sort((a, b) => ((Number(b.rating) || 0) * 20 + (Number(b.reviews) || 0)) - ((Number(a.rating) || 0) * 20 + (Number(a.reviews) || 0)))
        .slice(0, 8);
    }

    if (tab === "new") {
      return list.slice(0, 8);
    }

    return list
      .sort((a, b) => {
        const bScore = (Number(b.rating) || 0) * 14 + (Number(b.reviews) || 0) + (b.oldPrice ? 10 : 0);
        const aScore = (Number(a.rating) || 0) * 14 + (Number(a.reviews) || 0) + (a.oldPrice ? 10 : 0);
        return bScore - aScore;
      })
      .slice(0, 8);
  }, [products, tab]);

  return (
    <section className="mx-auto max-w-[1440px] px-4 py-10 sm:px-6 lg:px-8 lg:py-14">
      <div className="mb-6 flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <div className="mb-2 inline-flex items-center gap-2 text-xs font-black uppercase tracking-[0.16em] text-neon">
            <Sparkles className="h-4 w-4" /> NextPlay seçimi
          </div>
          <h2 className="font-display text-2xl font-black sm:text-3xl">Oyunlar və rəqəmsal məhsullar</h2>
          <p className="mt-1 text-sm text-muted-foreground">Kataloqdan ən çox diqqət çəkən məhsulları kəşf et.</p>
        </div>

        <Link to="/marketplace" className="hidden items-center gap-2 text-sm font-black text-neon hover:underline sm:inline-flex">
          Bütün kataloq <ArrowRight className="h-4 w-4" />
        </Link>
      </div>

      <div className="mb-6 flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        {tabs.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`inline-flex h-10 shrink-0 items-center gap-2 rounded-xl border px-4 text-xs font-black transition ${
              tab === id
                ? "border-neon/45 bg-neon text-background"
                : "border-border bg-surface/45 text-muted-foreground hover:border-neon/30 hover:text-foreground"
            }`}
          >
            <Icon className="h-3.5 w-3.5" /> {label}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, index) => <div key={index} className="aspect-[3/4] animate-pulse rounded-2xl bg-surface" />)}
        </div>
      ) : visible.length > 0 ? (
        <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4 xl:gap-5">
          {visible.map((product) => <ProductCard key={product.id} p={product} />)}
        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-border bg-surface/30 p-8 text-center text-sm text-muted-foreground">
          Bu bölmə üçün hazırda aktiv məhsul yoxdur.
        </div>
      )}

      <Link to="/marketplace" className="mt-6 flex h-11 items-center justify-center gap-2 rounded-xl border border-border text-sm font-black text-neon sm:hidden">
        Bütün kataloq <ArrowRight className="h-4 w-4" />
      </Link>
    </section>
  );
}

function discountPercent(product: Product) {
  const oldPrice = Number(product.oldPrice || 0);
  const price = Number(product.price || 0);
  if (!oldPrice || oldPrice <= price) return 0;
  return Math.round(((oldPrice - price) / oldPrice) * 100);
}
