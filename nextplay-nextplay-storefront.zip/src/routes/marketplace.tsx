import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ProductCard } from "@/components/ProductCard";
import { categories, CATEGORY_LABEL_AZ, boostScore } from "@/lib/marketplace-data";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { fetchProducts } from "@/lib/products";
import { supabase } from "@/integrations/supabase/client";
import { useEffect, useMemo, useState } from "react";
import { Search, SlidersHorizontal, X, Star, LayoutGrid, Grid3x3, List, RefreshCw, AlertCircle, ShieldCheck, Zap, Gamepad2, Monitor } from "lucide-react";
import { ProductGridSkeleton } from "@/components/Skeletons";
import { EmptyState } from "@/components/EmptyState";
import { z } from "zod";
import { zodValidator, fallback } from "@tanstack/zod-adapter";
import { trackSearch } from "@/lib/fbq";
import { useT } from "@/lib/i18n";

const searchSchema = z.object({
  q: fallback(z.string(), "").default(""),
  cat: fallback(z.string(), "all").default("all"),
  sub: fallback(z.string(), "all").default("all"),
  platform: fallback(z.string(), "all").default("all"),
  platforms: fallback(z.string(), "").default(""),
  psub: fallback(z.string(), "all").default("all"),
  delivery: fallback(z.enum(["all", "Instant", "Manual"]), "all").default("all"),
  min: fallback(z.number().min(0), 0).default(0),
  max: fallback(z.number().min(0), 0).default(0),
  rating: fallback(z.number().min(0).max(5), 0).default(0),
  verified: fallback(z.boolean(), false).default(false),
  inStock: fallback(z.boolean(), true).default(true),
  sort: fallback(z.enum(["popular", "low", "high", "rating", "newest"]), "popular").default("popular"),
});

export const Route = createFileRoute("/marketplace")({
  validateSearch: zodValidator(searchSchema),
  component: MarketplacePage,
  head: () => ({
    meta: [
      { title: "Marketplace — Oyunlar, hesablar və açarlar — NextPlay.az" },
      { name: "description", content: "NextPlay.az marketplace: müxtəlif oyunlar, hesablar, CD açarlar, gift kartlar və gaming xidmətləri. Filtrlə, müqayisə et, təhlükəsiz şəkildə al." },
      { property: "og:title", content: "NextPlay.az Marketplace — Oyunlar, hesablar, açarlar" },
      { property: "og:description", content: "Gaming məhsulları tək yerdə. Təhlükəsiz sifariş prosesi ilə alqı-satqı." },
      { property: "og:url", content: "https://nextplay.az/marketplace" },
    ],
    links: [{ rel: "canonical", href: "https://nextplay.az/marketplace" }],
  }),
});

function MarketplacePage() {
  const s = Route.useSearch();
  const t = useT();
  const navigate = useNavigate({ from: "/marketplace" });
  const update = (patch: Partial<typeof s>) =>
    navigate({ search: ((prev: any) => ({ ...prev, ...patch })) as any, replace: true });

  const [products, setProducts] = useState<import("@/lib/marketplace-data").Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [qLocal, setQLocal] = useState(s.q);
  const [view, setView] = useState<"compact" | "grid" | "list">("grid");
  const [subcats, setSubcats] = useState<{ slug: string; label_az: string; category_slug: string }[]>([]);
  const [platforms, setPlatforms] = useState<{ slug: string; label_az: string }[]>([]);
  const [psubs, setPsubs] = useState<{ slug: string; label_az: string; platform_slug: string }[]>([]);
  const shuffleSeed = useMemo(() => Math.random(), []);

  const loadProducts = async () => {
    setLoading(true);
    setError(false);
    try {
      const p = await fetchProducts();
      setProducts(p);
    } catch (err) {
      console.error("Marketplace fetch error:", err);
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadProducts(); }, []);

  useEffect(() => {
    supabase.from("subcategories" as any).select("slug,label_az,category_slug").eq("is_active", true).order("sort_order")
      .then(({ data }) => setSubcats(((data as any) ?? []) as any));
    supabase.from("platforms" as any).select("slug,label_az").eq("is_active", true).order("sort_order")
      .then(({ data }) => setPlatforms(((data as any) ?? []) as any));
    supabase.from("platform_subcategories" as any).select("slug,label_az,platform_slug").eq("is_active", true).order("sort_order")
      .then(({ data }) => setPsubs(((data as any) ?? []) as any));
  }, []);
  useEffect(() => { setQLocal(s.q); }, [s.q]);
  const currentSubs = s.cat !== "all" ? subcats.filter(x => x.category_slug === s.cat) : [];
  const currentPlatformSlug = platforms.find(p => p.label_az === s.platform)?.slug;
  const currentPsubs = s.platform !== "all" && currentPlatformSlug ? psubs.filter(x => x.platform_slug === currentPlatformSlug) : [];

  // Debounce free-text search → URL
  useEffect(() => {
    const t = setTimeout(() => { if (qLocal !== s.q) { update({ q: qLocal }); } }, 250);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [qLocal]);

  const filtered = useMemo(() => {
    let r = products.slice();
    if (s.cat !== "all") r = r.filter(p => p.category === s.cat);
    if (s.sub !== "all") r = r.filter(p => p.subcategory === s.sub);
    if (s.platform !== "all") r = r.filter(p => p.platform === s.platform);
    if ((s.platforms as string).trim()) {
      const list = (s.platforms as string).split(",").map((x: string) => x.trim().toLowerCase()).filter(Boolean);
      if (list.length) r = r.filter(p => list.includes((p.platform ?? "").toLowerCase()));
    }
    if (s.psub !== "all") r = r.filter(p => (p as any).platformSubcategory === s.psub);
    if (s.delivery !== "all") r = r.filter(p => p.delivery === s.delivery);
    if (s.verified) r = r.filter(p => p.seller?.verified);
    if (s.inStock) r = r.filter(p => (p.stock ?? 0) > 0);
    if (s.min > 0) r = r.filter(p => p.price >= s.min);
    if (s.max > 0) r = r.filter(p => p.price <= s.max);
    if (s.rating > 0) r = r.filter(p => (p.rating ?? 0) >= s.rating);
    if (s.q.trim()) {
      const q = s.q.toLowerCase();
      r = r.filter(p =>
        p.title.toLowerCase().includes(q) ||
        (p.description ?? "").toLowerCase().includes(q) ||
        (p.seller?.shopName ?? "").toLowerCase().includes(q) ||
        (p.seller?.name ?? "").toLowerCase().includes(q)
      );
    }
    const cmp = (a: any, b: any, fn: (x: any, y: any) => number) => {
      const bs = boostScore(b) - boostScore(a);
      return bs !== 0 ? bs : fn(a, b);
    };
    if (s.sort === "low") r.sort((a, b) => cmp(a, b, (x, y) => x.price - y.price));
    else if (s.sort === "high") r.sort((a, b) => cmp(a, b, (x, y) => y.price - x.price));
    else if (s.sort === "rating") r.sort((a, b) => cmp(a, b, (x, y) => y.rating - x.rating));
    else if (s.sort === "newest") r.sort((a, b) => cmp(a, b, (x, y) => (y.id > x.id ? 1 : -1)));
    else {
      // popular: boosted first, remaining shuffled (stable per visit)
      const hash = (id: string) => {
        let h = 0;
        const key = id + ":" + shuffleSeed;
        for (let i = 0; i < key.length; i++) h = ((h << 5) - h + key.charCodeAt(i)) | 0;
        return h;
      };
      r.sort((a, b) => {
        const bs = boostScore(b) - boostScore(a);
        if (bs !== 0) return bs;
        return hash(a.id) - hash(b.id);
      });
    }
    return r;
  }, [products, s, shuffleSeed]);


  const activeCount =
    (s.cat !== "all" ? 1 : 0) +
    (s.sub !== "all" ? 1 : 0) +
    (s.platform !== "all" ? 1 : 0) +
    ((s.platforms as string).trim() ? 1 : 0) +
    (s.psub !== "all" ? 1 : 0) +
    (s.delivery !== "all" ? 1 : 0) +
    (s.verified ? 1 : 0) +
    (s.min > 0 ? 1 : 0) +
    (s.max > 0 ? 1 : 0) +
    (s.rating > 0 ? 1 : 0);

  const reset = () => navigate({
    search: { q: "", cat: "all", sub: "all", platform: "all", platforms: "", psub: "all", delivery: "all", min: 0, max: 0, rating: 0, verified: false, inStock: true, sort: "popular" } as any,
    replace: true,
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <section className="border-b border-border bg-surface/30">
          <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-8 py-10">
            <div className="text-xs font-black uppercase tracking-[0.18em] text-neon">NextPlay mağaza</div>
            <h1 className="mt-2 font-display text-4xl sm:text-5xl font-black">Oyun kataloqu</h1>
            <p className="mt-3 text-muted-foreground max-w-2xl">
              {loading ? "Yüklənir..." : `${products.length} aktiv məhsul`} · PlayStation, PC və rəqəmsal məhsulları filtrlə və rahat tap.
            </p>

            <div className="mt-6 flex gap-2 overflow-x-auto pb-1 no-scrollbar">
              <button onClick={() => update({ platform: "all", platforms: "", psub: "all" })} className={`inline-flex h-10 shrink-0 items-center rounded-xl border px-4 text-xs font-black transition ${s.platform === "all" && !s.platforms ? "border-neon bg-neon text-background" : "border-border bg-background hover:border-neon/30"}`}>Hamısı</button>
              <button onClick={() => update({ platform: "all", platforms: "PlayStation,PS5,PS4", psub: "all", cat: "all" })} className={`inline-flex h-10 shrink-0 items-center gap-2 rounded-xl border px-4 text-xs font-black transition ${(s.platforms || "").includes("PlayStation") ? "border-neon bg-neon text-background" : "border-border bg-background hover:border-neon/30"}`}><Gamepad2 className="h-4 w-4" /> PlayStation</button>
              <button onClick={() => update({ platform: "all", platforms: "PC,Steam,EA,Epic Games,Epic,Rockstar,Battle.net", psub: "all", cat: "Games" })} className={`inline-flex h-10 shrink-0 items-center gap-2 rounded-xl border px-4 text-xs font-black transition ${(s.platforms || "").includes("Steam") ? "border-neon bg-neon text-background" : "border-border bg-background hover:border-neon/30"}`}><Monitor className="h-4 w-4" /> PC Oyunları</button>
              <button onClick={() => update({ platform: "Steam", platforms: "", psub: "all" })} className={`inline-flex h-10 shrink-0 items-center rounded-xl border px-4 text-xs font-black transition ${s.platform === "Steam" ? "border-neon bg-neon text-background" : "border-border bg-background hover:border-neon/30"}`}>Steam</button>
              <button onClick={() => update({ delivery: "Instant" })} className={`inline-flex h-10 shrink-0 items-center gap-1.5 rounded-xl border px-4 text-xs font-black transition ${s.delivery === "Instant" ? "border-neon bg-neon text-background" : "border-border bg-background hover:border-neon/30"}`}><Zap className="h-3.5 w-3.5" /> Anında çatdırılma</button>
            </div>

            <div className="mt-5 flex flex-col lg:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <input
                  value={qLocal}
                  onChange={e => setQLocal(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); update({ q: qLocal }); trackSearch(qLocal); } }}
                  placeholder="Məhsul, satıcı və ya mağaza axtar..."
                  className="w-full h-12 pl-12 pr-10 rounded-xl bg-background border border-border focus:outline-none focus:ring-2 focus:ring-ring"
                />
                {qLocal && (
                  <button onClick={() => setQLocal("")} className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded hover:bg-surface" aria-label="Sil">
                    <X className="h-4 w-4 text-muted-foreground" />
                  </button>
                )}
              </div>
              <select value={s.sort} onChange={e => update({ sort: e.target.value as typeof s.sort })}
                className="h-12 px-4 rounded-xl bg-background border border-border focus:outline-none focus:ring-2 focus:ring-ring min-w-[170px]">
                <option value="popular">Populyar</option>
                <option value="newest">Ən yenilər</option>
                <option value="low">Ən aşağı qiymət</option>
                <option value="high">Ən yüksək qiymət</option>
                <option value="rating">Reytinqə görə</option>
              </select>
            </div>

            <div className="mt-6 flex flex-wrap gap-2">
              {categories.map(c => {
                const count = c.id === "all" 
                  ? products.length 
                  : products.filter(p => p.category === c.id).length;
                return (
                  <button key={c.id} onClick={() => update({ cat: c.id, sub: "all" })}
                    className={`px-4 py-2 rounded-full text-sm font-medium transition border ${
                      s.cat === c.id
                        ? "bg-neon text-background border-transparent neon-ring"
                        : "bg-surface border-border text-muted-foreground hover:text-foreground hover:border-primary/40"
                    }`}>
                    {t(c.key as any)} <span className="opacity-60">({count})</span>
                  </button>
                );
              })}
            </div>

            {currentSubs.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-2">
                <button onClick={() => update({ sub: "all" })}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition ${
                    s.sub === "all" ? "bg-primary text-primary-foreground border-transparent" : "bg-background border-border text-muted-foreground hover:text-foreground"
                  }`}>
                  Hamısı
                </button>
                {currentSubs.map(sc => (
                  <button key={sc.slug} onClick={() => update({ sub: sc.slug })}
                    className={`px-3 py-1.5 rounded-full text-xs font-semibold border transition ${
                      s.sub === sc.slug ? "bg-primary text-primary-foreground border-transparent" : "bg-background border-border text-muted-foreground hover:text-foreground"
                    }`}>
                    {sc.label_az}
                  </button>
                ))}
              </div>
            )}
          </div>
        </section>

        <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-8 pt-6">
          <Breadcrumbs
            items={[
              { label: "Market", ...(s.cat !== "all" ? { to: "/marketplace" } : {}) },
              ...(s.cat !== "all" ? [{
                label: CATEGORY_LABEL_AZ[s.cat] ?? s.cat,
                ...(s.sub !== "all" || s.platform !== "all" ? { to: "/marketplace", search: { cat: s.cat } } : {}),
              }] : []),
              ...(s.sub !== "all" ? [{
                label: s.sub,
                ...(s.platform !== "all" ? { to: "/marketplace", search: { cat: s.cat, sub: s.sub } } : {}),
              }] : []),
              ...(s.platform !== "all" ? [{ label: s.platform }] : []),
            ]}
          />
        </div>

        <section className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-8 py-8 grid lg:grid-cols-[260px_1fr] gap-8">
          {/* Sidebar filters */}
          <aside className="space-y-6">
            <div className="rounded-xl border border-border bg-card-gradient p-3 sm:p-4 text-xs sm:text-sm">
              <div className="flex items-center justify-between mb-2 sm:mb-3">
                <h2 className="font-semibold text-xs sm:text-sm flex items-center gap-1.5 sm:gap-2">
                  <SlidersHorizontal className="h-3.5 w-3.5 sm:h-4 sm:w-4 text-neon" /> Filtrlər
                  {activeCount > 0 && <span className="text-[10px] bg-neon text-background rounded-full px-1.5 py-0.5">{activeCount}</span>}
                </h2>
                {activeCount > 0 && (
                  <button onClick={reset} className="text-[11px] sm:text-xs text-muted-foreground hover:text-foreground">Sıfırla</button>
                )}
              </div>

              <div className="space-y-3 sm:space-y-4">
                <div>
                  <label className="block text-[11px] sm:text-xs text-muted-foreground mb-1 sm:mb-1.5">Platforma</label>
                  <select value={s.platform} onChange={e => update({ platform: e.target.value, psub: "all" })}
                    className="w-full h-9 sm:h-10 px-2.5 sm:px-3 rounded-lg bg-background border border-border focus:outline-none focus:ring-2 focus:ring-ring text-xs sm:text-sm">
                    <option value="all">Bütün kateqoriyalar</option>
                    {platforms.map(p => <option key={p.slug} value={p.label_az}>{p.label_az}</option>)}
                  </select>
                </div>

                {currentPsubs.length > 0 && (
                  <div>
                    <label className="block text-[11px] sm:text-xs text-muted-foreground mb-1 sm:mb-1.5">Alt kateqoriya ({s.platform})</label>
                    <select value={s.psub} onChange={e => update({ psub: e.target.value })}
                      className="w-full h-9 sm:h-10 px-2.5 sm:px-3 rounded-lg bg-background border border-border focus:outline-none focus:ring-2 focus:ring-ring text-xs sm:text-sm">
                      <option value="all">Hamısı</option>
                      {currentPsubs.map(p => <option key={p.slug} value={p.slug}>{p.label_az}</option>)}
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-[11px] sm:text-xs text-muted-foreground mb-1 sm:mb-1.5">Çatdırılma</label>
                  <div className="grid grid-cols-3 gap-1">
                    {(["all", "Instant", "Manual"] as const).map(d => (
                      <button key={d} onClick={() => update({ delivery: d })}
                        className={`h-8 sm:h-9 rounded-lg text-[11px] sm:text-xs font-semibold border transition ${
                          s.delivery === d ? "bg-neon text-background border-transparent" : "bg-background border-border text-muted-foreground hover:text-foreground"
                        }`}>
                        {d === "all" ? "Hamısı" : d === "Instant" ? "⚡ Anında" : "Əl ilə"}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] sm:text-xs text-muted-foreground mb-1 sm:mb-1.5">Qiymət (₼)</label>
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <input type="number" min={0} value={s.min || ""} onChange={e => update({ min: Number(e.target.value) || 0 })}
                      placeholder="Min" className="w-full h-9 sm:h-10 px-2.5 sm:px-3 rounded-lg bg-background border border-border focus:outline-none focus:ring-2 focus:ring-ring text-xs sm:text-sm" />
                    <span className="text-muted-foreground">–</span>
                    <input type="number" min={0} value={s.max || ""} onChange={e => update({ max: Number(e.target.value) || 0 })}
                      placeholder="Max" className="w-full h-9 sm:h-10 px-2.5 sm:px-3 rounded-lg bg-background border border-border focus:outline-none focus:ring-2 focus:ring-ring text-xs sm:text-sm" />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] sm:text-xs text-muted-foreground mb-1 sm:mb-1.5">Minimum reytinq</label>
                  <div className="flex gap-1">
                    {[0, 3, 4, 4.5].map(r => (
                      <button key={r} onClick={() => update({ rating: r })}
                        className={`flex-1 h-8 sm:h-9 rounded-lg text-[11px] sm:text-xs font-semibold border transition inline-flex items-center justify-center gap-1 ${
                          s.rating === r ? "bg-neon text-background border-transparent" : "bg-background border-border text-muted-foreground hover:text-foreground"
                        }`}>
                        {r === 0 ? "Hamısı" : <><Star className="h-3 w-3 fill-current" />{r}+</>}
                      </button>
                    ))}
                  </div>
                </div>

                <label className="flex items-center gap-2 cursor-pointer text-[11px] sm:text-sm">
                  <input type="checkbox" checked={s.verified} onChange={e => update({ verified: e.target.checked })}
                    className="h-3.5 w-3.5 sm:h-4 sm:w-4 accent-neon" />
                  <span className="inline-flex items-center gap-1"><ShieldCheck className="h-3 w-3 sm:h-3.5 sm:w-3.5 text-sky-400" /> Yalnız doğrulanmış satıcılar</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-[11px] sm:text-sm">
                  <input type="checkbox" checked={s.inStock} onChange={e => update({ inStock: e.target.checked })}
                    className="h-3.5 w-3.5 sm:h-4 sm:w-4 accent-neon" />
                  <span className="inline-flex items-center gap-1"><Zap className="h-3 w-3 sm:h-3.5 sm:w-3.5 text-success" /> Yalnız stokda olanlar</span>
                </label>
              </div>
            </div>
          </aside>

          {/* Results */}
          <div>
            <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
              <p className="text-sm text-muted-foreground">
                {filtered.length} məhsul tapıldı
              </p>
              <div className="flex items-center gap-1 rounded-lg border border-border bg-card/40 p-1">
                <button
                  type="button"
                  aria-label="Sıx görünüş"
                  onClick={() => setView("compact")}
                  className={`grid h-7 w-7 place-items-center rounded-md transition ${view === "compact" ? "bg-neon text-background" : "text-muted-foreground hover:text-foreground"}`}
                >
                  <Grid3x3 className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  aria-label="Şəbəkə görünüşü"
                  onClick={() => setView("grid")}
                  className={`grid h-7 w-7 place-items-center rounded-md transition ${view === "grid" ? "bg-neon text-background" : "text-muted-foreground hover:text-foreground"}`}
                >
                  <LayoutGrid className="h-4 w-4" />
                </button>
                <button
                  type="button"
                  aria-label="Siyahı görünüşü"
                  onClick={() => setView("list")}
                  className={`grid h-7 w-7 place-items-center rounded-md transition ${view === "list" ? "bg-neon text-background" : "text-muted-foreground hover:text-foreground"}`}
                >
                  <List className="h-4 w-4" />
                </button>
              </div>
              {(s.q || activeCount > 0) && (
                <div className="flex flex-wrap gap-1.5 w-full">
                  {s.q && (
                    <Chip label={`"${s.q}"`} onClear={() => { setQLocal(""); update({ q: "" }); }} />
                  )}
                  {s.cat !== "all" && <Chip label={s.cat} onClear={() => update({ cat: "all", sub: "all" })} />}
                  {s.sub !== "all" && <Chip label={subcats.find(x => x.slug === s.sub)?.label_az ?? s.sub} onClear={() => update({ sub: "all" })} />}
                  {s.platform !== "all" && <Chip label={s.platform} onClear={() => update({ platform: "all", psub: "all" })} />}
                  {(s.platforms as string).trim() && <Chip label={(s.platforms as string).includes("PlayStation") ? "PlayStation" : (s.platforms as string).includes("Steam") ? "PC Oyunları" : "Platformalar"} onClear={() => update({ platforms: "" })} />}
                  {s.psub !== "all" && <Chip label={psubs.find(x => x.slug === s.psub)?.label_az ?? s.psub} onClear={() => update({ psub: "all" })} />}
                  {s.delivery !== "all" && <Chip label={s.delivery === "Instant" ? "⚡ Anında" : "Əl ilə"} onClear={() => update({ delivery: "all" })} />}
                  {s.min > 0 && <Chip label={`≥ ${s.min}₼`} onClear={() => update({ min: 0 })} />}
                  {s.max > 0 && <Chip label={`≤ ${s.max}₼`} onClear={() => update({ max: 0 })} />}
                  {s.rating > 0 && <Chip label={`★ ${s.rating}+`} onClear={() => update({ rating: 0 })} />}
                  {s.verified && <Chip label="Doğrulanmış" onClear={() => update({ verified: false })} />}
                </div>
              )}
            </div>

            {loading ? (
              <ProductGridSkeleton count={8} />
            ) : error ? (
              <div className="flex flex-col items-center justify-center py-20 px-4 text-center rounded-3xl border border-dashed border-border bg-surface/10">
                <div className="h-16 w-16 rounded-2xl bg-destructive/10 flex items-center justify-center mb-4">
                  <AlertCircle className="h-8 w-8 text-destructive" />
                </div>
                <h3 className="text-xl font-bold mb-2">Məlumat yüklənmədi</h3>
                <p className="text-muted-foreground mb-6 max-w-sm mx-auto">
                  Serverlə əlaqə zamanı xəta baş verdi. Zəhmət olmasa yenidən cəhd edin.
                </p>
                <button
                  onClick={loadProducts}
                  className="inline-flex items-center gap-2 h-11 px-6 rounded-xl bg-neon text-background font-semibold neon-ring"
                >
                  <RefreshCw className="h-4 w-4" /> Yenidən cəhd et
                </button>
              </div>
            ) : filtered.length === 0 ? (
              <EmptyState
                icon={Search}
                title="Heç bir nəticə tapılmadı"
                description="Axtarış sözünü və ya filtrləri dəyişib yenidən cəhd et."
                ctaLabel="Filtrləri sıfırla"
                ctaOnClick={reset}
              />
            ) : view === "list" ? (
              <div className="flex flex-col gap-2">
                {filtered.map(p => <ProductCard key={p.id} p={p} variant="list" />)}
              </div>
            ) : view === "compact" ? (
              <div className="grid gap-3 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-5">
                {filtered.map(p => <ProductCard key={p.id} p={p} variant="compact" />)}
              </div>
            ) : (
              <div className="grid gap-3 grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
                {filtered.map(p => <ProductCard key={p.id} p={p} />)}
              </div>
            )}
          </div>

        </section>
      </main>
      <Footer />
    </div>
  );
}

function Chip({ label, onClear }: { label: string; onClear: () => void }) {
  return (
    <span className="inline-flex items-center gap-1 h-7 px-2.5 rounded-full bg-surface border border-border text-xs">
      {label}
      <button onClick={onClear} className="hover:text-foreground text-muted-foreground" aria-label="Sil"><X className="h-3 w-3" /></button>
    </span>
  );
}
