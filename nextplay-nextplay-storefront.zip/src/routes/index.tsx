import { createFileRoute } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Hero } from "@/components/Hero";
import { BannerCarousel } from "@/components/BannerCarousel";
import { HomeCategoriesGrid } from "@/components/HomeCategoriesGrid";
import { SelectedProducts } from "@/components/SelectedProducts";
import { StatsSection } from "@/components/StatsSection";
import { HowItWorks } from "@/components/HowItWorks";
import { SellerCta } from "@/components/SellerCta";
import { MARKETPLACE_ENABLED } from "@/lib/store-mode";
import { LiveSalesTicker } from "@/components/LiveSalesTicker";
import { RecentlyViewed } from "@/components/RecentlyViewed";
import { GameFinder } from "@/components/GameFinder";
import { StoreTrustStrip } from "@/components/StoreTrustStrip";

const OG_IMAGE = "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/77eb5b66-c504-44a4-9793-fc26f7e0cbdb/id-preview-8d439908--95efcf38-dc42-4a79-833a-d0f4ebe2f022.lovable.app-1782745934722.png";

export const Route = createFileRoute("/")({
  component: HomePage,
  head: () => ({
    meta: [
      { title: "NextPlay.az — PlayStation və PC oyun mağazası" },
      { name: "description", content: "PlayStation və PC oyunları, hədiyyə kartları, rəqəmsal məhsullar və balans xidmətlərini NextPlay.az-da kəşf et." },
      { property: "og:title", content: "NextPlay.az — Oyun dünyasına növbəti addım" },
      { property: "og:description", content: "PlayStation və PC oyunları, hədiyyə kartları və rəqəmsal məhsullar bir məkanda." },
      { property: "og:url", content: "https://nextplay.az/" },
      { property: "og:image", content: OG_IMAGE },
      { name: "twitter:title", content: "NextPlay.az — PlayStation və PC oyun mağazası" },
      { name: "twitter:description", content: "Oyunları və rəqəmsal məhsulları rahat şəkildə kəşf et." },
      { name: "twitter:image", content: OG_IMAGE },
    ],
    links: [{ rel: "canonical", href: "https://nextplay.az/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "NextPlay.az",
          url: "https://nextplay.az",
          logo: "https://nextplay.az/icon-512.png",
          sameAs: [],
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: "NextPlay.az",
          url: "https://nextplay.az",
          potentialAction: {
            "@type": "SearchAction",
            target: "https://nextplay.az/marketplace?q={search_term_string}",
            "query-input": "required name=search_term_string",
          },
        }),
      },
    ],
  }),
});

function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <Hero />
        <StoreTrustStrip />
        <HomeCategoriesGrid />
        <SelectedProducts />
        <GameFinder />
        <BannerCarousel />
        <LiveSalesTicker />
        <div className="mx-auto max-w-[1440px] px-4 sm:px-6 lg:px-8">
          <RecentlyViewed />
        </div>
        <HowItWorks />
        <StatsSection />
        {MARKETPLACE_ENABLED && <SellerCta />}
      </main>
      <Footer />
    </div>
  );
}
