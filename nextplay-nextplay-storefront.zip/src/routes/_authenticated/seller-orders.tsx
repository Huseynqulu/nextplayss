import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/use-auth";
import { toast } from "sonner";
import { Loader2, Package, CheckCircle2, Truck, Clock, ShoppingBag, AlertTriangle, MessageSquare, ArrowLeft, ChevronRight, Search, X } from "lucide-react";
import { OrderListSkeleton } from "@/components/Skeletons";
import { EmptyState } from "@/components/EmptyState";
import { useCurrency } from "@/lib/currency";
import { SellerOrderDetailDialog } from "@/components/SellerOrderDetailDialog";

export const Route = createFileRoute("/_authenticated/seller-orders")({
  component: SellerOrdersPage,
  validateSearch: (s: Record<string, unknown>) => ({ open: typeof s.open === "string" ? s.open : undefined }),
  head: () => ({ meta: [{ title: "Gələn Sifarişlər — NextPlay.az" }] }),
});


type Order = {
  id: string;
  buyer_id: string;
  seller_id: string;
  product_id: string;
  quantity: number;
  unit_price: number;
  total: number;
  status: "pending" | "paid" | "delivered" | "completed" | "cancelled" | "refunded" | "dispute";
  delivery_payload: string | null;
  conversation_id: string | null;
  disputed_reason: string | null;
  created_at: string;
  product: { title: string; slug: string; image_url: string | null } | null;
};

const STATUS_LABEL: Record<string, { label: string; cls: string; icon: any }> = {
  paid: { label: "Çatdırılma gözləyir", cls: "bg-warning/20 text-warning", icon: Clock },
  delivered: { label: "Çatdırıldı", cls: "bg-primary/20 text-primary", icon: Truck },
  completed: { label: "Tamamlandı", cls: "bg-success/20 text-success", icon: CheckCircle2 },
  cancelled: { label: "Ləğv edildi", cls: "bg-muted text-muted-foreground", icon: Clock },
  refunded: { label: "Qaytarıldı", cls: "bg-muted text-muted-foreground", icon: Clock },
  dispute: { label: "Mübahisəli", cls: "bg-destructive/20 text-destructive", icon: AlertTriangle },
  pending: { label: "Gözləyir", cls: "bg-muted text-muted-foreground", icon: Clock },
};

function SellerOrdersPage() {
  const { user, roles } = useAuth() as any;
  const { format } = useCurrency();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [payloadInput, setPayloadInput] = useState<Record<string, string>>({});
  const [openOrder, setOpenOrder] = useState<Order | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (roles && !roles.includes("seller")) {
      navigate({ to: "/seller" });
    }
  }, [roles, navigate]);

  async function refresh() {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from("orders")
      .select("*, product:products(title, slug, image_url)")
      .eq("seller_id", user.id)
      .order("created_at", { ascending: false });
    if (error) toast.error(error.message);
    setOrders((data as any) ?? []);
    setLoading(false);
  }
  useEffect(() => { refresh(); /* eslint-disable-next-line */ }, [user]);

  const { open: openId } = useSearch({ from: "/_authenticated/seller-orders" });
  useEffect(() => {
    if (!openId || !orders.length) return;
    const found = orders.find(o => o.id === openId);
    if (found) setOpenOrder(found);
  }, [openId, orders]);


  async function deliver(o: Order) {
    const payload = payloadInput[o.id]?.trim();
    if (!payload) { toast.error("Çatdırılma məlumatı daxil edin"); return; }
    setBusy(o.id);
    const { error } = await supabase.rpc("mark_order_delivered", { p_order_id: o.id, p_payload: payload });
    setBusy(null);
    if (error) toast.error(error.message); else { toast.success("Çatdırıldı"); refresh(); }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-10">
          <Link to="/seller-dashboard" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-4">
            <ArrowLeft className="h-4 w-4" /> Satıcı Paneli
          </Link>
          <h1 className="font-display text-3xl sm:text-4xl font-bold flex items-center gap-3">
            <ShoppingBag className="h-7 w-7 text-neon" /> Gələn Sifarişlər
          </h1>
          <p className="text-muted-foreground mt-2 mb-4">Müştəri sifarişlərini buradan çatdırın.</p>

          <div className="mb-6 flex flex-wrap gap-2">
            <Link
              to="/orders"
              className="inline-flex items-center gap-1.5 h-9 px-3 rounded-lg border border-border bg-surface text-sm font-semibold hover:border-primary text-muted-foreground hover:text-foreground"
            >
              <ShoppingBag className="h-4 w-4" /> Aldığım sifarişlər
            </Link>
            <span className="inline-flex items-center gap-1.5 h-9 px-3 rounded-lg bg-neon text-background text-sm font-semibold">
              <Truck className="h-4 w-4" /> Satdığım sifarişlər
            </span>
          </div>


          {/* Filters */}
          <div className="mb-6 space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Məhsul adı, sifariş ID və ya çatdırılma məlumatı..."
                className="w-full h-11 pl-10 pr-10 rounded-xl bg-surface border border-border text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              />
              {search && (
                <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              {[
                { v: "all", label: "Hamısı" },
                { v: "paid", label: "Çatdırılma gözləyir" },
                { v: "delivered", label: "Çatdırıldı" },
                { v: "completed", label: "Tamamlandı" },
                { v: "dispute", label: "Mübahisəli" },
                { v: "cancelled", label: "Ləğv edildi" },
                { v: "refunded", label: "Qaytarıldı" },
              ].map(t => {
                const count = t.v === "all" ? orders.length : orders.filter(o => o.status === t.v).length;
                const active = statusFilter === t.v;
                return (
                  <button
                    key={t.v}
                    onClick={() => setStatusFilter(t.v)}
                    className={`inline-flex items-center gap-1.5 h-8 px-3 rounded-lg border text-xs font-semibold transition-colors ${
                      active ? "bg-neon text-background border-neon" : "bg-surface border-border text-muted-foreground hover:text-foreground hover:border-primary/50"
                    }`}
                  >
                    {t.label}
                    <span className={`px-1.5 rounded ${active ? "bg-background/20" : "bg-background/40"}`}>{count}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {(() => {
            const q = search.trim().toLowerCase();
            const filtered = orders.filter(o => {
              if (statusFilter !== "all" && o.status !== statusFilter) return false;
              if (!q) return true;
              return (
                o.product?.title?.toLowerCase().includes(q) ||
                o.id.toLowerCase().includes(q) ||
                (o.delivery_payload ?? "").toLowerCase().includes(q)
              );
            });
            return loading ? (
            <OrderListSkeleton count={4} />
          ) : orders.length === 0 ? (
            <EmptyState
              icon={Package}
              title="Hələ satış yoxdur"
              description="Məhsulunu əlavə et və ilk satışını qazan. Toplu CSV yükləmə də mövcuddur."
              ctaLabel="Məhsul əlavə et"
              ctaTo="/seller-dashboard"
              secondaryLabel="Bələdçi"
              secondaryTo="/user-guide"
            />
          ) : filtered.length === 0 ? (
            <EmptyState
              icon={Search}
              title="Nəticə tapılmadı"
              description="Axtarış və ya status filtrini dəyişdirib yenidən cəhd et."
            />
          ) : (
            <div className="space-y-3">
              {filtered.map(o => {
                const s = STATUS_LABEL[o.status] ?? STATUS_LABEL.pending;
                const Icon = s.icon;
                return (
                  <div
                    key={o.id}
                    onClick={() => setOpenOrder(o)}
                    className="rounded-2xl border border-border bg-card-gradient p-4 sm:p-5 card-shadow cursor-pointer hover:border-primary/60 transition-colors"
                  >
                    <div className="flex gap-3 sm:gap-4">
                      {o.product?.image_url ? (
                        <img src={o.product.image_url} alt="" className="h-16 w-16 sm:h-20 sm:w-20 rounded-xl object-cover shrink-0" />
                      ) : (
                        <div className="h-16 w-16 sm:h-20 sm:w-20 rounded-xl bg-surface grid place-items-center shrink-0"><Package className="h-6 w-6 text-muted-foreground" /></div>
                      )}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-3">
                          <div className="min-w-0 flex-1">
                            <h3 className="font-semibold truncate">{o.product?.title ?? "Məhsul"}</h3>
                            <p className="text-xs text-muted-foreground mt-1">
                              {o.quantity} ədəd · {format(o.unit_price)} · {new Date(o.created_at).toLocaleString("az-AZ")}
                            </p>
                            <div className="mt-2 flex items-center gap-2 flex-wrap">
                              <span className="font-display text-base sm:text-lg font-bold text-gradient">{format(o.total)}</span>
                              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase ${s.cls}`}>
                                <Icon className="h-3 w-3" /> {s.label}
                              </span>
                            </div>
                          </div>
                          <ChevronRight className="h-5 w-5 text-muted-foreground shrink-0 mt-1" />
                        </div>



                        <div className="mt-3 flex flex-wrap gap-2" onClick={e => e.stopPropagation()}>
                          {o.conversation_id && (
                            <Link to="/messages/$conversationId" params={{ conversationId: o.conversation_id }}
                              className="inline-flex items-center gap-1.5 h-9 px-3 rounded-lg border border-border bg-surface text-sm font-semibold hover:border-primary">
                              <MessageSquare className="h-4 w-4" /> Söhbət
                            </Link>
                          )}
                          {o.status === "dispute" && (
                            <span className="inline-flex items-center gap-1.5 h-9 px-3 rounded-lg bg-warning/10 border border-warning/40 text-warning text-xs font-semibold">
                              <AlertTriangle className="h-4 w-4" /> Etiraz {o.disputed_reason ? `· ${o.disputed_reason}` : ""}
                            </span>
                          )}
                        </div>

                        {o.status === "paid" && (
                          <div className="mt-3 flex gap-2 flex-wrap" onClick={e => e.stopPropagation()}>
                            <input
                              value={payloadInput[o.id] ?? ""}
                              onChange={e => setPayloadInput(p => ({ ...p, [o.id]: e.target.value }))}
                              placeholder="Açar / hesab məlumatı..."
                              className="flex-1 min-w-[200px] h-9 px-3 rounded-lg bg-background border border-border text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                            />
                            <button
                              disabled={busy === o.id}
                              onClick={() => deliver(o)}
                              className="inline-flex items-center gap-1.5 h-9 px-3 rounded-lg bg-neon text-background text-sm font-semibold hover:opacity-90 disabled:opacity-50"
                            >
                              <Truck className="h-4 w-4" /> Çatdır
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          );
          })()}
        </div>
      </main>
      <Footer />
      {openOrder && (
        <SellerOrderDetailDialog
          order={openOrder as any}
          onClose={() => setOpenOrder(null)}
          onChanged={refresh}
        />
      )}
    </div>
  );
}
